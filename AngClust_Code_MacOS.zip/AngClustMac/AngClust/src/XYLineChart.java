import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlElementDecl.GLOBAL;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.data.time.Month;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class XYLineChart {

	protected Shell shell;
	private Text txtGenes;
	private Button btnClear;
	private Button btnOriginalExpression;
	private Button btnShiftedExpression;
	private Text txtYmin;
	private Text txtYmax;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			XYLineChart window = new XYLineChart();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(550, 400);
		shell.setText("Data for Line Chart");

		txtGenes = new Text(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL
				| SWT.CANCEL | SWT.MULTI);
		txtGenes.setText("YLR222C\r\nYLR129W\r\nYML026C\r\nYJR002W\r\nYML093W\r\nYPR112C\r\nYOL010W\r\nYJL136C\r\nYDL153C\r\nYBR247C\r\nYDR450W\r\nYOR310C\r\nYNL308C\r\nYKR057W\r\nYGL171W\r\nYPR144C\r\nYOR294W\r\nYLR048W\r\nYDR449C\r\nYOR004W\r\nYCR057C\r\nYDL148C\r\nYKL099C\r\nYMR229C\r\nYGR214W\r\nYFR001W\r\nYHR169W\r\nYCL059C");
		txtGenes.setBounds(10, 35, 510, 259);

		Label lblGenes = new Label(shell, SWT.NONE);
		lblGenes.setBounds(10, 10, 54, 12);
		lblGenes.setText("Genes");

		btnOriginalExpression = new Button(shell, SWT.RADIO);
		btnOriginalExpression.setSelection(true);
		btnOriginalExpression.setBounds(33, 318, 199, 16);
		btnOriginalExpression.setText("Original Expression");

		btnShiftedExpression = new Button(shell, SWT.RADIO);
		btnShiftedExpression.setBounds(33, 340, 177, 16);
		btnShiftedExpression.setText("Shifted Expression");

		Button btnDrawGraph = new Button(shell, SWT.NONE);
		btnDrawGraph.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				XYSeriesCollection lineDataset = new XYSeriesCollection();
				String genesString = txtGenes.getText();
				genesString = genesString.replace('\n', ',');
				genesString = genesString.replace('\r', ',');
				genesString = genesString.replace('\t', ',');
				genesString = genesString.replace(' ', ',');
				genesString = genesString.replace(",,", ",");
				genesString = genesString.replace(",,", ",");

				String[] genesArray = genesString.split(",");
				XYSeries[] tsArraySeries = new XYSeries[genesArray.length];

				if (GlobalVars.geneSymbols == null) {
					MessageBox messageBox = new MessageBox(shell, SWT.OK
							 | SWT.ICON_WARNING);
					messageBox
							.setMessage("Expression data have not been loaded.");
					messageBox.open();
					return;
				}

				for (int i = 0; i < genesArray.length; i++) {
					tsArraySeries[i] = new XYSeries(genesArray[i]);

					// data
					//todo:  �������ݵ��ļ��У����ں����ķ�����
					
					// Write gene symbols into txt files
					// Folder path
					Date now = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
					String pathString = Utilities.DefaultFilePath()
							+"\\"+ sdf.format(now);
					File file = new File(pathString);
					file.mkdirs();
					FileWriter fw2 = null;
					 
						try {
							fw2 = new FileWriter(pathString + "\\"
									+  "OneCluster.txt", true);
							
							
							for (int j = 0; j < GlobalVars.geneSymbols.length; j++) {
								if (genesArray[i]
										.equalsIgnoreCase(GlobalVars.geneSymbols[j])) {
									fw2.append(GlobalVars.geneSymbols[j] + "\t");
									for (int k = 0; k < GlobalVars.pointCount; k++) {
										if (btnOriginalExpression.getSelection()) {
											tsArraySeries[i].add(GlobalVars.timePoints[k],
													GlobalVars.originExpr[j][k]);
											fw2.append(String.valueOf(GlobalVars.originExpr[j][k]) + "\t");
										} else {
											tsArraySeries[i].add(GlobalVars.timePoints[k],
													GlobalVars.shiftedExpr[j][k]);
											fw2.append(String.valueOf(GlobalVars.shiftedExpr[j][k]) + "\t");
										}

									}
									fw2.append( "\r\n");
									break;
								}
							}

							fw2.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					 
					
				

					//
					lineDataset.addSeries(tsArraySeries[i]);
				}

				JFreeChart chart = ChartFactory
						.createXYLineChart("Time Series Expression", "Time("+GlobalVars.TimeUnit+")",
								"Expression", lineDataset,
								PlotOrientation.VERTICAL, true, true, true);
				// sub title
				TextTitle subtitle = new TextTitle("", new Font("", Font.BOLD,
						12));
				chart.addSubtitle(subtitle);
				// main title
				chart.setTitle(new TextTitle("", new Font("", Font.ITALIC, 15)));
				chart.setAntiAlias(true);
				chart.removeLegend();

				//����x��ķ�Χ
				XYPlot plot = (XYPlot) chart.getPlot();
				NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
				//rangeAxis.setRange(Double.valueOf(txtYmin.getText()), Double.valueOf(txtYmax.getText()));
				//����y��ķ�Χ				
				rangeAxis.setRange(Double.valueOf(txtYmin.getText()), Double.valueOf(txtYmax.getText()));
				//
				plot.setBackgroundPaint(Color.WHITE);
				plot.setWeight(50);
				
				//
				XYLineAndShapeRenderer xylineandshaperenderer = (XYLineAndShapeRenderer)plot.getRenderer();
		        xylineandshaperenderer.setSeriesShape(0, new java.awt.Rectangle(100,100,50,50)); 
		 


				//
				ChartFrame frame = new ChartFrame(
						"Time Series Expression Graph", chart, true);
				frame.setBounds(100, 100, 100, 70);//
				frame.setSize(100, 70);//
				frame.pack();
				frame.setVisible(true);

			}
		});
		btnDrawGraph.setBounds(451, 316, 81, 22);
		btnDrawGraph.setText("Draw Graph");

		btnClear = new Button(shell, SWT.NONE);
		btnClear.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				txtGenes.setText("");
				txtGenes.paste();
			}
		});
		btnClear.setBounds(392, 7, 128, 22);
		btnClear.setText("Clear and Paste");
		
		txtYmin = new Text(shell, SWT.BORDER);
		txtYmin.setText("-7");
		txtYmin.setBounds(375, 314, 70, 18);
		
		txtYmax = new Text(shell, SWT.BORDER);
		txtYmax.setText("7");
		txtYmax.setBounds(375, 338, 70, 18);
		
		Label lblYMin = new Label(shell, SWT.NONE);
		lblYMin.setBounds(315, 317, 54, 12);
		lblYMin.setText("Y min");
		
		Label lblYMax = new Label(shell, SWT.NONE);
		lblYMax.setText("Y max");
		lblYMax.setBounds(315, 336, 54, 12);

	}
}
