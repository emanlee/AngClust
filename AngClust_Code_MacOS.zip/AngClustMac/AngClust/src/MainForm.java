import org.eclipse.swt.widgets.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class MainForm {


	public static void main(String[] args) {
		final Display display=Display.getDefault();
		final Shell shell=new Shell();
		shell.setSize(800,600);
		shell.setText("AngClust - Angle-based Clustering (Version 1.0)");
		
		

		int width=shell.getDisplay().getBounds().width;  
		int height=shell.getDisplay().getBounds().height;   
		 
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
		
		
		
		int buttonSizeHeight=24;
		
		 

		
			// button Load Data
			Button btnLoadData = new Button(shell, SWT.NONE);
			btnLoadData.setBounds(10, 10, 150, buttonSizeHeight);
			btnLoadData.setText("Load Data");
			btnLoadData.setToolTipText("Load Data");
			btnLoadData.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					LoadGeneExpr window = new LoadGeneExpr();
					window.open();
				}
			});
			
			// button Similarity
			Button btnSimilarity = new Button(shell, SWT.NONE);
			btnSimilarity.setBounds(10+150+10, 10, 150, buttonSizeHeight);
			btnSimilarity.setText("Similarity");
			btnSimilarity.setToolTipText("Similarity");
			btnSimilarity.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					SimilarityMatrix window = new SimilarityMatrix();
					window.open();
				}
			});
			
			// button APClustering
			Button btnAPClustering = new Button(shell, SWT.NONE);
			btnAPClustering.setBounds(10+150+150+20, 10, 150, buttonSizeHeight);
			btnAPClustering.setText("AP Clustering");
			btnAPClustering.setToolTipText("AP Clustering");
			btnAPClustering.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					APClustering window = new APClustering();
					window.open();
				}
			});
		 
		//=====================================================
		shell.layout();
		shell.open();
		while(!shell.isDisposed()){
			if(!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	
	}
}
