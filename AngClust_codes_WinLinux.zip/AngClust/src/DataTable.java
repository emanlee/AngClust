import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.wb.swt.layout.grouplayout.GroupLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.layout.grouplayout.LayoutStyle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;
/* ��ʾTable,��������ΪVector���͵ģ����Ե������ı��ļ��� */
public class DataTable {

	protected Shell shell;
	private String title;
	private Vector tableClomnHeader;
	private Vector tableRows=null;

	public DataTable(String windowTitle, Vector TableClomnHeader,
			Vector TableRows) {
		title = windowTitle;
		tableClomnHeader = TableClomnHeader;
		tableRows = TableRows;
	}

	public static void main(String[] args) {
		try {
			DataTable window = new DataTable("", null, null);
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	protected void createContents() {
		shell = new Shell();
		shell.setSize(800, 600);
		shell.setText(title);

		int width=shell.getDisplay().getBounds().width; // �ҵ�createContents����������õ���Ļ�Ŀ��ȡ�
		int height=shell.getDisplay().getBounds().height; // ����������У��õ���Ļ�ĸ߶ȡ�
		// �õ���Ļ�Ŀ��߶ȼ�ȥshell���ڵĿ��Ⱥ͸߶ȣ�����2�õ����ڵ����Ͻ����ꡣ
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
		
		
		final Table table = new Table(shell, SWT.BORDER | SWT.MULTI);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		Button btnExport = new Button(shell, SWT.NONE);
		btnExport.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {


				FileWriter fw = null;
				try {
					fw = new FileWriter(Utilities.DefaultFilePath()+"\\DataTableTmp.txt");
					for (int i = 0; i < tableRows.size(); i++) {
						Vector vrow=(Vector)tableRows.elementAt(i);
						
						fw.write((String)vrow.get(0) +"\t"+(String)vrow.get(1)  +"\t"
								+(String)vrow.get(2) +"\t"+(String)vrow.get(3) +"\r\n");
					}
					fw.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				

			}
		});
		btnExport.setText("Export");
		
		Label lblExportToDatatabletmptxt = new Label(shell, SWT.NONE);
		lblExportToDatatabletmptxt.setText("Export to DataTableTmp.txt");
		GroupLayout gl_shell = new GroupLayout(shell);
		gl_shell.setHorizontalGroup(
			gl_shell.createParallelGroup(GroupLayout.LEADING)
				.add(gl_shell.createSequentialGroup()
					.add(gl_shell.createParallelGroup(GroupLayout.LEADING)
						.add(table, GroupLayout.DEFAULT_SIZE, 781, Short.MAX_VALUE)
						.add(gl_shell.createSequentialGroup()
							.addContainerGap()
							.add(btnExport)
							.add(104)
							.add(lblExportToDatatabletmptxt, GroupLayout.PREFERRED_SIZE, 247, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		gl_shell.setVerticalGroup(
			gl_shell.createParallelGroup(GroupLayout.TRAILING)
				.add(gl_shell.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.add(table, GroupLayout.PREFERRED_SIZE, 519, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(LayoutStyle.RELATED)
					.add(gl_shell.createParallelGroup(GroupLayout.BASELINE)
						.add(btnExport)
						.add(lblExportToDatatabletmptxt))
					.add(19))
		);
		shell.setLayout(gl_shell);
		
		for (int i = 0; i < tableClomnHeader.size(); i++) {
			TableColumn tableColumn = new TableColumn(table, SWT.NONE);
			tableColumn.setText(tableClomnHeader.elementAt(i).toString());
			tableColumn.setWidth(80);
		}
		for (int i = 0; i < tableRows.size(); i++) {
			Vector v = (Vector) (tableRows.elementAt(i));
			String[] stringArray = new String[v.size()];
			for (int index = 0; index < v.size(); index++) {
				stringArray[index] = (String) v.get(index);
			}

			TableItem tableItem = new TableItem(table, 0);
			tableItem.setText(stringArray);
		}

	}
}
