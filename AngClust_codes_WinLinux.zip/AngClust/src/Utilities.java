import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class Utilities {

	
	public static boolean APClusteringLogAllData=false;
	
	/**
	 * read file line one by one , splitted with comma
	 * @param fileName
	 */
	public static String readFileByLines(String fileName) {
        File file = new File(fileName);
        BufferedReader reader = null;
        String str="";
        try {
           
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            //  
            while ((tempString = reader.readLine()) != null) {
                //  
            	str+=tempString+",";
                line++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        return str;
    }
	
	public static String DefaultFilePath()
	{		
		//if the folder does not exist we create it
		String pathString="";
		File directory = new File("");//�趨Ϊ��ǰ�ļ���		 
		pathString=directory.getAbsolutePath();
		return  pathString; //"F:\\ClusteringResults\\"; //todo: test on Windows, Linux, Ubunto, Solaris etc.
	}
	
}
