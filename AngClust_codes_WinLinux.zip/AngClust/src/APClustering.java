import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.List;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.eclipse.swt.widgets.Label;
 

//import APClusterForJava.*;
import org.eclipse.swt.widgets.Text;

public class APClustering {

	protected Shell shell;
	//private Button btnOriginalExpression;
	private Text txtIDX;
	private Text txtClusteredFilePath; // Folder path for output results.

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			APClustering window = new APClustering();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(707, 452);
		shell.setText("AP Clustering");
		int width=shell.getDisplay().getBounds().width; // �ҵ�createContents����������õ���Ļ�Ŀ�ȡ�
		int height=shell.getDisplay().getBounds().height; // ����������У��õ���Ļ�ĸ߶ȡ�
		// �õ���Ļ�Ŀ�߶ȼ�ȥshell���ڵĿ�Ⱥ͸߶ȣ�����2�õ����ڵ����Ͻ����ꡣ
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
	
		int buttonSizeHeight=23;
	
		
		final Label lblClusterIndex = new Label(shell, SWT.NONE);
		lblClusterIndex.setBounds(10, 15, 140, buttonSizeHeight);
		lblClusterIndex.setText("Cluster index");
		
		final Label lblClusterFiles = new Label(shell, SWT.NONE);
		lblClusterFiles.setBounds(150, 15, 198, buttonSizeHeight);
		lblClusterFiles.setText("Cluster files");
		
		final Label lblClusterCount = new Label(shell, SWT.NONE);
		lblClusterCount.setBounds(150+250, 15, 120, buttonSizeHeight);
		lblClusterCount.setText("-");
		
		Button btnCluster = new Button(shell, SWT.NONE);
		btnCluster.setBounds(530, 15-8, 72, buttonSizeHeight);
		btnCluster.setText("Cluster");
		
		// button close
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setText("Close");
		button.setBounds(490+72+5+40, 15-8, 72, buttonSizeHeight);
				
				
		
		txtIDX = new Text(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL
				| SWT.CANCEL | SWT.MULTI);
		txtIDX.setBounds(10, 20+20, 104, 309+30);
		
		// list, show all clustering results (files)
		final List lstClusteredFiles = new List(shell, SWT.BORDER
				| SWT.H_SCROLL | SWT.V_SCROLL);
		lstClusteredFiles.setBounds(150, 20+20, 460+50+10, 309+30);
		
		
		
		final Label lblTimeConsumed = new Label(shell, SWT.NONE);
		lblTimeConsumed.setBounds(250+100, 70+309+10, 220, 19);
		lblTimeConsumed.setText("-");
		
		
		//final Button btnApclusteringlogalldata = new Button(shell, SWT.CHECK);

		
		btnCluster.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				
				if(GlobalVars.pointCount==0)
				{
					
					MessageBox messageBox =
						    new MessageBox(shell,
						     SWT.OK|
						     SWT.ICON_WARNING);
						messageBox.setMessage("Gene expression was not loaded or similarity was not calculated.");
						messageBox.open(); 		
						return;
					
				}
				
				
				long timeConsumed = System.currentTimeMillis();

				//if (btnApclusteringlogalldata.getSelection()) {
				//	Utilities.APClusteringLogAllData = true; // log (log records) ?
				//} else {
				//	Utilities.APClusteringLogAllData = false;
				// }

				lblClusterCount.setText("Running...");
				
				double[][] s = GlobalVars.SimilarityMatrix;
				double p = apcluster.median_for_apcluster(s);
				// System.out.println("p= " + String.valueOf(p) + " \r\n");

				int[] idx = apcluster.ap(s, p, false, false, false, 1000,
						false, 100, false, 0.9);

				// ============================================================
				// begin Call from Matlab

				/*
				 * System.out.println("\rAPClusterInJava Time consumed 1: " +
				 * (System.currentTimeMillis() - timeConsumed) / 1000f +
				 * " seconds ");
				 * 
				 * MWNumericArray sa = null; Object[] result = null;
				 * APClusterInJava apjava = null;
				 * 
				 * try { // int[] dims = {490000-700, 3}; int[] dims = { 39800,
				 * 3 }; sa = MWNumericArray.newInstance(dims, MWClassID.DOUBLE,
				 * MWComplexity.REAL);
				 * 
				 * int[] index = { 1, 1 }; System.out.println("Exception 11 ");
				 * for (index[0] = 1; index[0] <= dims[0]; index[0]++) { for
				 * (index[1] = 1; index[1] <= dims[1]; index[1]++) {
				 * sa.set(index, s[index[0] - 1][index[1] - 1]);
				 * 
				 * } } System.out.println("Exception 22 "); apjava = new
				 * APClusterInJava(); result = apjava.apclusterKJava(1, sa,10);
				 * System.out.println("Exception: 22 ");
				 * System.out.println(result[0]); MWArray.disposeArray(result);
				 * }
				 * 
				 * catch (Exception ex) { System.out.println("Exception: " +
				 * ex.toString()); }
				 * 
				 * finally {
				 * 
				 * MWArray.disposeArray(sa); MWArray.disposeArray(result); if
				 * (apjava != null) apjava.dispose(); }
				 * 
				 * System.out.println("\rAPClusterInJava Time consumed 2: " +
				 * (System.currentTimeMillis() - timeConsumed) / 1000f +
				 * " seconds ");
				 */
				// ============================================================
				// end

				
				String pathfileConnector= "/";
				
				if(OSinfo.isWindows()) {pathfileConnector="\\";  } // Windows, Linux, MacOS?
				
				// Folder path for output results.
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				String pathString = Utilities.DefaultFilePath() + pathfileConnector + sdf.format(now);
				GlobalVars.clusterFilesPath = pathString;
				//txtClusteredFilePath.setText(pathString); // Folder path for output results.
				File file = new File(pathString);
				file.mkdirs();

				// Write gene symbols into txt files
				FileWriter fw2 = null;
				for (int i = 0; i < idx.length; i++) {
					try {
						fw2 = new FileWriter(pathString + pathfileConnector + String.valueOf(idx[i]) + ".txt", true);
						fw2.append(GlobalVars.geneSymbols[i] + "\r\n");
						fw2.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}

				//
				String idxsString = "";
				for (int i = 0; i < idx.length; i++) {
					// System.out.println(String.valueOf(idx[i]));
					idxsString += String.valueOf(i+1) +": "+ String.valueOf(idx[i]) + "\r\n";
				}
				txtIDX.setText(idxsString); // show 

				// Load file names to lstClusteredFiles
				File file2 = new File(pathString);
				if (file2.isDirectory()) {
					String[] filelist = file2.list();
					lblClusterCount.setText("Cluster count: "+ String.valueOf(filelist.length));
					 
					lblClusterFiles.setText("Clusters (click to show graph)");
					for (int i = 0; i < filelist.length; i++) {
						File readfile = new File(pathString + pathfileConnector + filelist[i]);
						if (!readfile.isDirectory()) {
							lstClusteredFiles.add(readfile.getPath());
							/*
							 * System.out.println("absolutepath=" +
							 * readfile.getAbsolutePath());
							 * System.out.println("name=" + readfile.getName());
							 */

						}
					}
				}

				// Time consumed
				lblTimeConsumed.setText("Time consumed : "
						+ (System.currentTimeMillis() - timeConsumed) / 1000f
						+ " seconds ");

				// Draw XY Lines
				lstClusteredFiles.addMouseListener(new MouseListener() {
					public void mouseDoubleClick(MouseEvent arg0) {
					}

					public void mouseDown(MouseEvent arg0) {
					}

					public void mouseUp(MouseEvent evt) {
						if (lstClusteredFiles.getSelectionIndex() >= 0
								&& lstClusteredFiles.getItemCount() > 0) {
							;
						}
						int ilist = lstClusteredFiles.getSelectionIndex();
						if (ilist >= 0) {
							lstClusteredFiles.setSelection(ilist);

							// Open file and get gene symbols
							String strGenes = Utilities.readFileByLines(lstClusteredFiles.getItem(ilist).toString());

							// draw XY Lines
							XYSeriesCollection lineDataset = new XYSeriesCollection();
							String genesString = strGenes;
							genesString = genesString.replace('\n', ',');
							genesString = genesString.replace('\r', ',');
							genesString = genesString.replace('\t', ',');
							genesString = genesString.replace(' ', ',');
							genesString = genesString.replace(",,", ",");
							genesString = genesString.replace(",,", ",");

							String[] genesArray = genesString.split(","); // gene symbols
							XYSeries[] tsArraySeries = new XYSeries[genesArray.length];

							if (GlobalVars.geneSymbols == null) {
								MessageBox messageBox = new MessageBox(shell, SWT.OK | SWT.ICON_WARNING);
								messageBox.setMessage("Expression data have not been loaded.");
								messageBox.open();
								return;
							}

							for (int i = 0; i < genesArray.length; i++) {
								tsArraySeries[i] = new XYSeries(genesArray[i]);

								// data

								for (int j = 0; j < GlobalVars.geneSymbols.length; j++) {
									if (genesArray[i].equalsIgnoreCase(GlobalVars.geneSymbols[j])) {
										for (int k = 0; k < GlobalVars.pointCount; k++) {
											//if (btnOriginalExpression.getSelection()) {
												tsArraySeries[i].add(k,GlobalVars.originExpr[j][k]); // gene expression data
											//} else {
											//	tsArraySeries[i].add(k,GlobalVars.shiftedExpr[j][k]);
											//}

										}
										break;
									}
								}

								//
								lineDataset.addSeries(tsArraySeries[i]);
							}

							JFreeChart chart = ChartFactory.createXYLineChart(
									"Time Series Gene Expression", "Time("+ GlobalVars.TimeUnit  +")",
									"Expression", lineDataset,
									PlotOrientation.VERTICAL, true, true, true);
							// sub title
							TextTitle subtitle = new TextTitle("", new Font("",
									Font.BOLD, 12));
							chart.addSubtitle(subtitle);
							// main title
							chart.setTitle(new TextTitle("Gene Expression", new Font("",
									Font.ITALIC, 15)));
							chart.setAntiAlias(true);
							 chart.setBackgroundPaint(Color.WHITE);
							  XYPlot plot= chart.getXYPlot();
							 plot.setBackgroundPaint(Color.WHITE);
							chart.removeLegend();

							ChartFrame frame = new ChartFrame(
									"Time Series Gene Expression Graph", chart, true);
							frame.pack();
							
							int width=shell.getDisplay().getBounds().width; // �ҵ�createContents����������õ���Ļ�Ŀ�ȡ�
							int height=shell.getDisplay().getBounds().height; // ����������У��õ���Ļ�ĸ߶ȡ�
							// �õ���Ļ�Ŀ�߶ȼ�ȥshell���ڵĿ�Ⱥ͸߶ȣ�����2�õ����ڵ����Ͻ����ꡣ
							int x=(width-shell.getBounds().width)/2;
							int y=(height-shell.getBounds().height)/2;
							frame.setLocation(x, y);							
							
							frame.setVisible(true);
							//

							/*
							 * MessageBox mBox=new MessageBox(shell);
							 * mBox.setMessage("OK"); mBox.open();
							 */

						}
					}
				});
			}
		});
	

		//btnOriginalExpression = new Button(shell, SWT.RADIO);
		//btnOriginalExpression.setText("Original Expression");
		//btnOriginalExpression.setSelection(true);
		//btnOriginalExpression.setBounds(325, 12, 169, 16);

		//Button btnShiftedExpression = new Button(shell, SWT.RADIO);
		//btnShiftedExpression.setText("Shifted Expression");
		//btnShiftedExpression.setBounds(323, 47, 169, 16);

		//btnApclusteringlogalldata.setBounds(325, 92, 179, 16);
		//btnApclusteringlogalldata.setText("APClusteringLogAllData");
		
		//txtClusteredFilePath = new Text(shell, SWT.BORDER);
		//txtClusteredFilePath.setBounds(10, 375, 388, 20);
		//txtClusteredFilePath.setVisible(false);

	}
}
