import org.eclipse.swt.widgets.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class MainForm {


	public static void main(String[] args) {
		final Display display=Display.getDefault();
		final Shell shell=new Shell();
		shell.setSize(800,600);
		shell.setText("AngClust - Angle-based Clustering (Version 1.0)");
		
		

		int width=shell.getDisplay().getBounds().width;  
		int height=shell.getDisplay().getBounds().height; // 
		// 
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
		
		
		
		int buttonSizeHeight=24;
		
		if(OSinfo.isMacOS() ) { 

		
			// button Load Data
			Button btnLoadData = new Button(shell, SWT.NONE);
			btnLoadData.setBounds(10, 10, 150, buttonSizeHeight);
			btnLoadData.setText("Load Data");
			btnLoadData.setToolTipText("Load Data");
			btnLoadData.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					LoadGeneExpr window = new LoadGeneExpr();
					window.open();
				}
			});
			
			// button Similarity
			Button btnSimilarity = new Button(shell, SWT.NONE);
			btnSimilarity.setBounds(10+150+10, 10, 150, buttonSizeHeight);
			btnSimilarity.setText("Similarity");
			btnSimilarity.setToolTipText("Similarity");
			btnSimilarity.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					SimilarityMatrix window = new SimilarityMatrix();
					window.open();
				}
			});
			
			// button APClustering
			Button btnAPClustering = new Button(shell, SWT.NONE);
			btnAPClustering.setBounds(10+150+150+20, 10, 150, buttonSizeHeight);
			btnAPClustering.setText("AP Clustering");
			btnAPClustering.setToolTipText("AP Clustering");
			btnAPClustering.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					APClustering window = new APClustering();
					window.open();
				}
			});
		}
		else
		{
		
		
			Menu menu = new Menu(shell, SWT.BAR);
			shell.setMenuBar(menu);
			
			//=====================================================
			// Data
			
			MenuItem mntmData = new MenuItem(menu, SWT.CASCADE);
			mntmData.setText("Data"); // MAiN MENU
			
			Menu menu_1 = new Menu(mntmData);
			mntmData.setMenu(menu_1);
			
			MenuItem mntmLoadData = new MenuItem(menu_1, SWT.NONE);
			mntmLoadData.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {				
					
					LoadGeneExpr window = new LoadGeneExpr();
					window.open();
				}
			});
			mntmLoadData.setText("Load Data"); // SUB MENU
			
			 
			
			//=====================================================
			// 	Similarity Matrix
			
			MenuItem mntmCluster = new MenuItem(menu, SWT.CASCADE);
			mntmCluster.setText("Similarity"); // MAiN MENU
			
			Menu menu_2 = new Menu(mntmCluster);
			mntmCluster.setMenu(menu_2);
			
			MenuItem mntmSimilarityMatrix = new MenuItem(menu_2, SWT.NONE);
			mntmSimilarityMatrix.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					SimilarityMatrix window = new SimilarityMatrix();
					window.open();
				}
			});
			mntmSimilarityMatrix.setText("Similarity"); // SUB MENU
			
			
			 
			//=====================================================
			// Clustering
			
			MenuItem mntmResults = new MenuItem(menu, SWT.CASCADE);
			mntmResults.setText("Cluster"); // MAiN MENU
			
			Menu menu_3 = new Menu(mntmResults);
			mntmResults.setMenu(menu_3);
			
			
			MenuItem mntmApClustering = new MenuItem(menu_3, SWT.NONE);
			mntmApClustering.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					APClustering window = new APClustering();
					window.open();
				}
			});
			mntmApClustering.setText("AP Clustering"); // SUB MENU
			
		}
		 
		//=====================================================
		shell.layout();
		shell.open();
		while(!shell.isDisposed()){
			if(!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	
	}
}
