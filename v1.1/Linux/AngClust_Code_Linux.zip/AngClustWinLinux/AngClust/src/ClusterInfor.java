

import java.util.ArrayList;
import java.util.List;

public class ClusterInfor
{	
	
    private String name;
    
    private int level;
    
    private int hasChildren;    // 0=none,  1=has
    
    private int isRealCluster;   // 0=virtual , 1=real/ original
   

    public int getIsRealCluster() {
		return isRealCluster;
	}


	public void setIsRealCluster(int isRealCluster) {
		this.isRealCluster = isRealCluster;
	}


	public ClusterInfor(String name)
    {
        this.name = name;    
        this.hasChildren=0; // 0, 1
        this.level=0; // 0,1,2,3,...
        this.isRealCluster=0; //0, 1 
    }


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}


	public int getHasChildren() {
		return hasChildren;
	}


	public void setHasChildren(int hasChildren) {
		this.hasChildren = hasChildren;
	}

    
    
   

    
  
}
