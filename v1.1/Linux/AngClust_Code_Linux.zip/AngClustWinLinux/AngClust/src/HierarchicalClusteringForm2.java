import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.List;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
//import java.util.List;

import com.apporiented.algorithm.clustering.AverageLinkageStrategy;
import com.apporiented.algorithm.clustering.Cluster;
import com.apporiented.algorithm.clustering.ClusteringAlgorithm;
import com.apporiented.algorithm.clustering.DefaultClusteringAlgorithm;
import com.apporiented.algorithm.clustering.visualization.DendrogramPanel;

import org.eclipse.swt.widgets.Label;
 

//import APClusterForJava.*;
import org.eclipse.swt.widgets.Text;

public class HierarchicalClusteringForm2 {

	protected Shell shell;
	//private Button btnOriginalExpression;
	//private Text txtIDX;
	private Text txtClusteredFilePath; // Folder path for output results.
	 
	private Text txtMessage;
	private Label lblMessage;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	 static  GraphicsConfiguration gc;
		static java.util.List<ClusterInfor> clusterInfor_global=new ArrayList<>();
		static Cluster cluster_global =null;
		static int hasChild_global=0;
		static int maxLevel_global=0;
		static java.util.List<String> Names_global=new ArrayList<>();
		
		
	public static void main(String[] args) {
		try {
			HierarchicalClusteringForm2 window = new HierarchicalClusteringForm2();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(707, 582);
		shell.setText("Hierarchical Clustering");
		int width=shell.getDisplay().getBounds().width; // 
		int Level=shell.getDisplay().getBounds().height; // 
		// 
		int x=(width-shell.getBounds().width)/2;
		int y=(Level-shell.getBounds().height)/2;
		shell.setLocation(x, y);
	
		int buttonSizeLevel=23;	
	 
		
		if(OSinfo.isWindows()) {GlobalVars.pathfileConnector="\\"; GlobalVars.lineEnd="\r\n";  } // Windows, Linux, MacOS?

		
		final Label lblClusterFiles = new Label(shell, SWT.NONE);
		lblClusterFiles.setBounds(15, 15+30, 198, buttonSizeLevel);
		lblClusterFiles.setText("Cluster files");
		
		final Label lblClusterCount = new Label(shell, SWT.NONE);
		lblClusterCount.setBounds(150+250, 15+30, 120, buttonSizeLevel);
		lblClusterCount.setText("-");
		
		Button btnCluster = new Button(shell, SWT.NONE);
		btnCluster.setBounds(530, 15-8+30, 72, buttonSizeLevel);
		btnCluster.setText("Cluster");
		
		txtMessage =  new Text(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL
				| SWT.CANCEL | SWT.MULTI);
		lblMessage = new Label(shell, SWT.NONE);
		
		// button close
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setText("Close");
		button.setBounds(490+72+5+40, 15-8+30, 72, buttonSizeLevel);
				
				
		
		//txtIDX = new Text(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL	| SWT.CANCEL | SWT.MULTI);
		//txtIDX.setBounds(10, 20+20+30, 104, 309+30);
		
		// list, show all clustering results (files)
		final List lstClusteredFiles = new List(shell, SWT.BORDER
				| SWT.H_SCROLL | SWT.V_SCROLL);
		lstClusteredFiles.setBounds(15, 20+20+30, 460+50+10+145, 309+30);
		
		lblMessage.setBounds(15, 20+20+30+309+30+5+5, 460+50+10+145, 30);
		lblMessage.setText("Statistics:");

		txtMessage.setBounds(15, 20+20+30+309+30+5+30, 460+50+10+145, 80);
		
		final Label lblTimeConsumed = new Label(shell, SWT.NONE);
		lblTimeConsumed.setBounds(250+100, 70+309+10+30, 220, 19);
		lblTimeConsumed.setText("-");
		
		
		//final Button btnApclusteringlogalldata = new Button(shell, SWT.CHECK);

		
		btnCluster.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				
				if(GlobalVars.pointCount==0)
				{
					
					MessageBox messageBox =
						    new MessageBox(shell,
						     SWT.OK|
						     SWT.ICON_WARNING);
						messageBox.setMessage("Gene expression was not loaded or similarity was not calculated.");
						messageBox.open(); 		
						return;
					
				}
				
				
				long timeConsumed = System.currentTimeMillis();

				//if (btnApclusteringlogalldata.getSelection()) {
				//	Utilities.APClusteringLogAllData = true; // log (log records) ?
				//} else {
				//	Utilities.APClusteringLogAllData = false;
				// }

				lblClusterCount.setText("Running...");
				
				//double[][] s = GlobalVars.SimilarityMatrix;
				 
				
				ClusteringAlgorithm alg = new DefaultClusteringAlgorithm();
				// Cluster cluster = alg.performClustering(distances, names,   new AverageLinkageStrategy());
				
				
				 Cluster cluster = alg.performClustering(GlobalVars.distances, GlobalVars.geneSymbols, new AverageLinkageStrategy());
				 cluster_global=cluster;
				
				 
				
				DendrogramPanel dp = new DendrogramPanel();
				dp.setModel(cluster);
				 
				//dp.setOpaque(true);
				//dp.setBackground(Color.WHITE);
				
				
				JFrame frame= new JFrame(gc);	
				frame.setTitle("Hierarchical Clustering");
				frame.setSize(1200, 1000);
				frame.add(dp, BorderLayout.CENTER);
				//frame.setOpaque(true);
				//frame.setBackground(Color.WHITE);
				frame.setVisible(true);
				

				
				 String pathfileConnector= "/";
				 String lineEnd="\n";
					
				if(OSinfo.isWindows()) {pathfileConnector="\\";  lineEnd="\r\n"; } // Windows, Linux, MacOS?
				
				// Folder path for output results.
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				String pathString = Utilities.DefaultFilePath() + pathfileConnector + sdf.format(now);
				GlobalVars.clusterFilesPath = pathString;
				//txtClusteredFilePath.setText(pathString); // Folder path for output results.
				File file = new File(pathString);
				file.mkdirs();

				// Write gene symbols into txt files
				FileWriter fw2 = null;
					
					
				
				//traverseTreeNodes(cluster);
				
				// Get clusterInfor_global (name, level, hasChildren, isRealCluster)
				traverseTreeNodes_2(cluster,0);
				String statistics="";
				// Get clusters by level: 0, 1, 2, 3. ...
				// for(int Level=0; Level<=maxLevel_global; Level++) {
				for(int Level=0; Level<=(maxLevel_global>6?6:maxLevel_global); Level++) {
					statistics=statistics+"Level "+String.valueOf(Level+1)+" ";
					
					//System.out.println("\n *******Final level: "+ String.valueOf(Level) + "\n");
					
					// clusterInfor_global
					 int cluster_count=0;
					 for (ClusterInfor ci : clusterInfor_global) {
		            	 if(ci.getLevel()==Level) {   
		            		 cluster_count++;
		            		 //System.out.println( ci.getName() + ": ");
		            		 Names_global=new ArrayList<>();
		            		 
		            		 output_Children(cluster_global, ci.getName());
		            		 int element_count=0; 
	     					try {
	     						fw2 = new FileWriter(pathString + pathfileConnector + String.valueOf("Level_"+ String.valueOf(Level+1) +"_"+ci.getName().replace("#", "_")) + ".txt", true);
	     						if(!ci.getName().contains("clstr"))
	     		            	{
	     							element_count++;
	     							fw2.append(ci.getName() + lineEnd);
	     		            	}     		            	 
	     						
	     						for (String ss : Names_global) {  
	     							element_count++;
	     								fw2.append(ss + lineEnd);
	     						 }
	     						
	     						fw2.close();
	     					} catch (IOException e1) {
	     						e1.printStackTrace();
	     					}
	     					 statistics=statistics+"" + element_count+ ", ";	 

		            		
		            		 
		            		 
		            	 }
		            	 if(ci.getLevel() < Level && ci.getHasChildren()==0) {
		            		 cluster_count++;
		            		 Names_global=new ArrayList<>();
		            		 
		            		 //System.out.println( ci.getName() + ": ");
		            		 int element_count=0;
		            		 try {
		  						fw2 = new FileWriter(pathString + pathfileConnector + String.valueOf("Level_"+ String.valueOf(Level+1) +"_"+ci.getName().replace("#", "_")) + ".txt", true);
		  						if(!ci.getName().contains("clstr"))
		  		            	{
		  							element_count++;
		  							fw2.append(ci.getName() + lineEnd);
		  		            	}     		            	 
		  						
		  						for (String ss : Names_global) {    
		  							element_count++;
		  								fw2.append(ss + lineEnd);
		  						 }
		  						
		  						fw2.close();
		  					} catch (IOException e1) {
		  						e1.printStackTrace();
		  					}
		            		 statistics=statistics+"" + element_count+ ", ";
		            		 
		            	 }
		            	 
		             }
					 statistics=statistics+" cluster_count= " + cluster_count+ ";" +  GlobalVars.lineEnd;
					 
					
				}
				//System.out.println(statistics+ "\n"); 
				txtMessage.setText(statistics);
				
				 
 

				// Load file names to lstClusteredFiles
				File file2 = new File(pathString);
				if (file2.isDirectory()) {
					String[] filelist = file2.list();
					lblClusterCount.setText("Cluster count: "+ String.valueOf(filelist.length));
					 
					lblClusterFiles.setText("Clusters (click to show graph)");
					for (int i = 0; i < filelist.length; i++) {
						File readfile = new File(pathString + pathfileConnector + filelist[i]);
						if (!readfile.isDirectory()) {
							lstClusteredFiles.add(readfile.getPath());
							/*
							 * System.out.println("absolutepath=" +
							 * readfile.getAbsolutePath());
							 * System.out.println("name=" + readfile.getName());
							 */

						}
					}
				}

				saveAllChartsAsFile(lstClusteredFiles);
				
				// Time consumed
				lblTimeConsumed.setText("Time consumed : "
						+ (System.currentTimeMillis() - timeConsumed) / 1000f
						+ " seconds ");
				
				

				// Draw XY Lines
				lstClusteredFiles.addMouseListener(new MouseListener() {
					public void mouseDoubleClick(MouseEvent arg0) {
					}

					public void mouseDown(MouseEvent arg0) {
					}

					public void mouseUp(MouseEvent evt) {
						if (lstClusteredFiles.getSelectionIndex() >= 0
								&& lstClusteredFiles.getItemCount() > 0) {
							;
						}
						int ilist = lstClusteredFiles.getSelectionIndex();
						if (ilist >= 0) {
							lstClusteredFiles.setSelection(ilist);

							// Open file and get gene symbols
							String strGenes = Utilities.readFileByLines(lstClusteredFiles.getItem(ilist).toString());

							// draw XY Lines
							XYSeriesCollection lineDataset = new XYSeriesCollection();
							String genesString = strGenes;
							genesString = genesString.replace('\n', ',');
							genesString = genesString.replace('\r', ',');
							genesString = genesString.replace('\t', ',');
							genesString = genesString.replace(' ', ',');
							genesString = genesString.replace(",,", ",");
							genesString = genesString.replace(",,", ",");

							String[] genesArray = genesString.split(","); // gene symbols
							XYSeries[] tsArraySeries = new XYSeries[genesArray.length];

							if (GlobalVars.geneSymbols == null) {
								MessageBox messageBox = new MessageBox(shell, SWT.OK | SWT.ICON_WARNING);
								messageBox.setMessage("Expression data have not been loaded.");
								messageBox.open();
								return;
							}

							for (int i = 0; i < genesArray.length; i++) {
								tsArraySeries[i] = new XYSeries(genesArray[i]);

								// data

								for (int j = 0; j < GlobalVars.geneSymbols.length; j++) {
									if (genesArray[i].equalsIgnoreCase(GlobalVars.geneSymbols[j])) {
										for (int k = 0; k < GlobalVars.pointCount; k++) {
											//if (btnOriginalExpression.getSelection()) {
												tsArraySeries[i].add(GlobalVars.timePoints[k],GlobalVars.originExpr[j][k]); // gene expression data
											//} else {
											//	tsArraySeries[i].add(k,GlobalVars.shiftedExpr[j][k]);
											//}

										}
										break;
									}
								}

								//
								lineDataset.addSeries(tsArraySeries[i]);
							}

							JFreeChart chart = ChartFactory.createXYLineChart(
									"Gene Expression", "Time("+ GlobalVars.TimeUnit  +")",
									"Expression", lineDataset,
									PlotOrientation.VERTICAL, true, true, true);
							// sub title
							TextTitle subtitle = new TextTitle("", new Font("",
									Font.BOLD, 12));
							chart.addSubtitle(subtitle);
							// main title
							chart.setTitle(new TextTitle("Gene Expression", new Font("",
									Font.ITALIC, 15)));
							chart.setAntiAlias(true);
							 chart.setBackgroundPaint(Color.WHITE);
							  XYPlot plot= chart.getXYPlot();
							 plot.setBackgroundPaint(Color.WHITE);
							chart.removeLegend();

							ChartFrame frame = new ChartFrame(
									"Gene Expression Graph", chart, true);
							frame.pack();
							
							saveAsFile(chart, lstClusteredFiles.getItem(ilist).toString()+".png",707,452);
							
							int width=shell.getDisplay().getBounds().width; // 
							int Level=shell.getDisplay().getBounds().height; // 
							//  
							int x=(width-shell.getBounds().width)/2;
							int y=(Level-shell.getBounds().height)/2;
							frame.setLocation(x, y);							
							
							frame.setVisible(true);
							//GlobalVars.distances 

							/*
							 * MessageBox mBox=new MessageBox(shell);
							 * mBox.setMessage("OK"); mBox.open();
							 */

						}
					}
				});
			}
		});
	

		//btnOriginalExpression = new Button(shell, SWT.RADIO);
		//btnOriginalExpression.setText("Original Expression");
		//btnOriginalExpression.setSelection(true);
		//btnOriginalExpression.setBounds(325, 12, 169, 16);

		//Button btnShiftedExpression = new Button(shell, SWT.RADIO);
		//btnShiftedExpression.setText("Shifted Expression");
		//btnShiftedExpression.setBounds(323, 47, 169, 16);

		//btnApclusteringlogalldata.setBounds(325, 92, 179, 16);
		//btnApclusteringlogalldata.setText("APClusteringLogAllData");
		
		//txtClusteredFilePath = new Text(shell, SWT.BORDER);
		//txtClusteredFilePath.setBounds(10, 375, 388, 20);
		//txtClusteredFilePath.setVisible(false);

	}
	
	
	protected void saveAllChartsAsFile(List lstClusteredFiles) {
		
		int ItemCount=lstClusteredFiles.getItemCount();
		String pathfileConnector= "/";
		
		if(OSinfo.isWindows()) {pathfileConnector="\\";  } // Windows, Linux, MacOS?
		
		for(int xx=0; xx<ItemCount; xx++)
		{
			String fileName=lstClusteredFiles.getItem(xx).toString();
			fileName=fileName.substring(fileName.lastIndexOf(pathfileConnector)+1).replace(".txt", "") ;
			
			
		 

		// Open file and get gene symbols
		String strGenes = Utilities.readFileByLines(lstClusteredFiles.getItem(xx).toString());

		// draw XY Lines
		XYSeriesCollection lineDataset = new XYSeriesCollection();
		String genesString = strGenes;
		genesString = genesString.replace('\n', ',');
		genesString = genesString.replace('\r', ',');
		genesString = genesString.replace('\t', ',');
		genesString = genesString.replace(' ', ',');
		genesString = genesString.replace(",,", ",");
		genesString = genesString.replace(",,", ",");

		String[] genesArray = genesString.split(","); // gene symbols
		XYSeries[] tsArraySeries = new XYSeries[genesArray.length];

		if (GlobalVars.geneSymbols == null) {
			MessageBox messageBox = new MessageBox(shell, SWT.OK | SWT.ICON_WARNING);
			messageBox.setMessage("Expression data have not been loaded.");
			messageBox.open();
			return;
		}

		for (int i = 0; i < genesArray.length; i++) {
			tsArraySeries[i] = new XYSeries(genesArray[i]);

			// data

			for (int j = 0; j < GlobalVars.geneSymbols.length; j++) {
				if (genesArray[i].equalsIgnoreCase(GlobalVars.geneSymbols[j])) {
					for (int k = 0; k < GlobalVars.pointCount; k++) {
						//if (btnOriginalExpression.getSelection()) {
							tsArraySeries[i].add(GlobalVars.timePoints[k],GlobalVars.originExpr[j][k]); // gene expression data
						//} else {
						//	tsArraySeries[i].add(k,GlobalVars.shiftedExpr[j][k]);
						//}

					}
					break;
				}
			}

			//
			lineDataset.addSeries(tsArraySeries[i]);
		}

		JFreeChart chart = ChartFactory.createXYLineChart(
				"Gene Expression, Cluster "+fileName, "Time("+ GlobalVars.TimeUnit  +")",
				"Expression", lineDataset,
				PlotOrientation.VERTICAL, true, true, true);
		// sub title
		TextTitle subtitle = new TextTitle("", new Font("",
				Font.BOLD, 12));
		chart.addSubtitle(subtitle);
		// main title
		chart.setTitle(new TextTitle("Gene Expression, Cluster "+fileName, new Font("",
				Font.ITALIC, 15)));
		chart.setAntiAlias(true);
		 chart.setBackgroundPaint(Color.WHITE);
		  XYPlot plot= chart.getXYPlot();
		 plot.setBackgroundPaint(Color.WHITE);
		chart.removeLegend();

		ChartFrame frame = new ChartFrame(
				"Gene Expression Graph", chart, true);
		frame.pack();
		
		saveAsFile(chart, lstClusteredFiles.getItem(xx).toString()+".png",707,452);
		
		 
		//

		/*
		 * MessageBox mBox=new MessageBox(shell);
		 * mBox.setMessage("OK"); mBox.open();
		 */
		}
	}
	
	
	 public static void saveAsFile(JFreeChart chart, String outputPath,  int width, int Level) { 
	        FileOutputStream out = null;     
	        try {
	            File outFile = new File(outputPath);    

	            if (!outFile.getParentFile().exists()) {    
	                outFile.getParentFile().mkdirs(); 
	            }      

	            out = new FileOutputStream(outputPath);   
	            // 保存为PNG      

	            ChartUtilities.writeChartAsPNG(out, chart, width, Level);   
	            // 保存为JPEG   
	            // ChartUtilities.writeChartAsJPEG(out, chart, weight, Level); 

	            out.flush();    

	        } catch (FileNotFoundException e) {    

	            e.printStackTrace();     

	        } catch (IOException e) {   
	            e.printStackTrace();   

	        } finally {      
	            if (out != null) { 
	                try {  
	                    out.close(); 
	                } catch (IOException e) {     
	                    // do nothing      

	                }      

	            }      

	        }      

	    }      
 
	
	
	private static void traverseTreeNodes_2(Cluster cluster, int level) {
	    
	    if (cluster != null) {
	       
	        for (Cluster child : cluster.getChildren()) {
	        	ClusterInfor clInf=new ClusterInfor(child.getName());
	        	//System.out.println(child.getName());   // for test
	        	int ll= getLevel(cluster,0);
	        	if(ll>maxLevel_global) {maxLevel_global=ll;}
	        	clInf.setLevel(ll);
	        	
	        	clInf.setHasChildren(traverseTreeNodes_to_hasChildren(cluster_global,child.getName())); 
	        	if(clInf.getName().contains("clstr"))
	        	{
	        		clInf.setIsRealCluster(0);
	        	}
	        	else
	        	{
	        		clInf.setIsRealCluster(1);
	        	}
	        	
	        	clusterInfor_global.add(clInf);
	        	
	        	
	        	//System.out.println(" level "+ String.valueOf(ll) + ";" );   	  // for test            	
	        	
	            /* Traverse cluster node tree */
	        	traverseTreeNodes_2(child,  level );	                
	        }
	    }
	    
	}

	
	private static int traverseTreeNodes_to_hasChildren(Cluster cluster, String name) {
	
	  
	    if (cluster != null) {
	        //traverseTreeNodes(cluster );
	    	String myname=cluster.getName();
	    	 if(myname.equals(name))
	            {
	    		 java.util.List<Cluster> c=cluster.getChildren();
	            	 if (c.isEmpty()  )
	     	        {
	            		 hasChild_global=0; 
	     	        }
	     	        else
	     	        {
	     	        	hasChild_global=1; 
	     	        }        
	            	return hasChild_global;
	            }
	    	
	         for (Cluster child : cluster.getChildren()) {
	        	 
	         	traverseTreeNodes_to_hasChildren(child, name );
	         	
	            
	        }
	    }
	     
	    return hasChild_global;
	    //
	    
	}


	private static void output_Children(Cluster cluster, String name) {
	
	  
	    if (cluster != null) {
	        
	    	String myname=cluster.getName();
	    	if(myname.equals(name))
	         {
	    		 	print_nodes(cluster);
	         }
	    	
	        for (Cluster child : cluster.getChildren()) {
	        	 
	        	output_Children(child, name );
	         	
	            
	        }
	    }
	     
	 
	    
	}


	private static void print_nodes(Cluster cluster) {
	
	  
	    if (cluster != null) {
	        
	       
	         for (Cluster child : cluster.getChildren()) {
	        	//System.out.println(child.getName() + " ");
	        	if(! child.getName().contains("clstr") ) 
	        	{
	        		Names_global.add(child.getName());
	        	}
	        	
	        	
	            /* Traverse cluster node tree */
	        	print_nodes(child );
	         	
	            
	        }
	    }
	    
	}



	private static void traverseTreeNodes(Cluster cluster) {
	
	  
	    if (cluster != null) {
	        //traverseTreeNodes(cluster );
	       
	        double distance = cluster.getDistanceValue() == null ? 0 : cluster.getDistanceValue();
	        for (Cluster child : cluster.getChildren()) {
	        	//System.out.println(child.getName());
	            int childLeafCount = child.countLeafs();
	           
	            double childDistance = child.getDistanceValue() == null ? 0 : child.getDistanceValue();
	          
	
	            /* Traverse cluster node tree */
	         traverseTreeNodes(child );
	         	
	            
	        }
	    }
	    
	}


	// todo: add level
	private static void traverseTreeNodes(Cluster cluster, int level  ) {
	  
	    if (cluster != null) {
	        //traverseTreeNodes(cluster );
	    	//level=level+1;
	    	//System.out.println(" level "+ String.valueOf(level) + ";");
	         for (Cluster child : cluster.getChildren()) {
	        	System.out.println(child.getName());   
	        	int ll= getLevel(cluster,0);
	        	System.out.println(" Level "+ String.valueOf(ll) + ";" );   	            	
	        	
	            /* Traverse cluster node tree */
	        	traverseTreeNodes(child,  level );	                
	        }
	    }
	    
	}








	private static void SetLevelForAllNodes(Cluster cluster, int level  ) {
	
	  
	    if (cluster != null) {
	        //traverseTreeNodes(cluster );
	    	//level=level+1;
	    	//System.out.println(" level "+ String.valueOf(level) + ";");
	        for (Cluster child : cluster.getChildren()) {
	        	 
	        	  setLevelForOneNode(cluster,0) ;   
	        	
	        	
	            /* Traverse cluster node tree */
	        	  SetLevelForAllNodes(child,  level );	                
	        }
	    }
	    
	}


	public static int getLevel(Cluster cluster,int level)
	{
	    
	    if ( cluster.getParent()==null)
	    {
	    	cluster.setLevel(level);
	        return level;
	    }
	    else
	    {
	    	level=level+1;
	    	return getLevel(cluster.getParent(),level);
	    	
	    }        
	
	}


	public static int getHasChildren(Cluster cluster)
	{
	    
	    if ( cluster.getChildren()==null)
	    {
	    	//cluster.setLevel(level);
	        return 0;
	    }
	    else
	    {
	    	//level=level+1;
	    	return 1;
	    	
	    }        
	
	}






	public static void setLevelForOneNode(Cluster cluster,int level)
	{	        
	    if ( cluster.getParent()==null)
	    {
	    	cluster.setLevel(level);	           
	    }
	    else
	    {
	    	level=level+1;
	    	setLevelForOneNode(cluster.getParent(),level);	        	
	    }        
	
	}
	
	}
