import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.List;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.apporiented.algorithm.clustering.AverageLinkageStrategy;
import com.apporiented.algorithm.clustering.Cluster;
import com.apporiented.algorithm.clustering.ClusteringAlgorithm;
import com.apporiented.algorithm.clustering.DefaultClusteringAlgorithm;
import com.apporiented.algorithm.clustering.visualization.DendrogramPanel;

import org.eclipse.swt.widgets.Label;
 

//import APClusterForJava.*;
import org.eclipse.swt.widgets.Text;

public class HierarchialClusteringForm {

	protected Shell shell;
	//private Button btnOriginalExpression;
	private Text txtIDX;
	private Text txtClusteredFilePath; // Folder path for output results.

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	 static  GraphicsConfiguration gc;
	public static void main(String[] args) {
		try {
			HierarchialClusteringForm window = new HierarchialClusteringForm();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(707, 452);
		shell.setText("AP Clustering");
		int width=shell.getDisplay().getBounds().width; // �ҵ�createContents����������õ���Ļ�Ŀ�ȡ�
		int height=shell.getDisplay().getBounds().height; // ����������У��õ���Ļ�ĸ߶ȡ�
		// �õ���Ļ�Ŀ�߶ȼ�ȥshell���ڵĿ�Ⱥ͸߶ȣ�����2�õ����ڵ����Ͻ����ꡣ
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
	
		int buttonSizeHeight=23;
	
		
		final Label lblClusterIndex = new Label(shell, SWT.NONE);
		lblClusterIndex.setBounds(10, 15, 140, buttonSizeHeight);
		lblClusterIndex.setText("Cluster index");
		
		final Label lblClusterFiles = new Label(shell, SWT.NONE);
		lblClusterFiles.setBounds(150, 15, 198, buttonSizeHeight);
		lblClusterFiles.setText("Cluster files");
		
		final Label lblClusterCount = new Label(shell, SWT.NONE);
		lblClusterCount.setBounds(150+250, 15, 120, buttonSizeHeight);
		lblClusterCount.setText("-");
		
		Button btnCluster = new Button(shell, SWT.NONE);
		btnCluster.setBounds(530, 15-8, 72, buttonSizeHeight);
		btnCluster.setText("Cluster");
		
		// button close
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setText("Close");
		button.setBounds(490+72+5+40, 15-8, 72, buttonSizeHeight);
				
				
		
		txtIDX = new Text(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL
				| SWT.CANCEL | SWT.MULTI);
		txtIDX.setBounds(10, 20+20, 104, 309+30);
		
		// list, show all clustering results (files)
	 
		
		
		final Label lblTimeConsumed = new Label(shell, SWT.NONE);
		lblTimeConsumed.setBounds(250+100, 70+309+10, 220, 19);
		lblTimeConsumed.setText("-");
		
		
		//final Button btnApclusteringlogalldata = new Button(shell, SWT.CHECK);

		
		btnCluster.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

			 
				
				long timeConsumed = System.currentTimeMillis();

				//if (btnApclusteringlogalldata.getSelection()) {
				//	Utilities.APClusteringLogAllData = true; // log (log records) ?
				//} else {
				//	Utilities.APClusteringLogAllData = false;
				// }

				lblClusterCount.setText("Running...");
			 
			 
				// System.out.println("p= " + String.valueOf(p) + " \r\n");

		 
				

				
				String pathfileConnector= "/";
				
				if(OSinfo.isWindows()) {pathfileConnector="\\";  } // Windows, Linux, MacOS?
				
				// Folder path for output results.
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			 
				
				String[] names = new String[] { "O1", "O2", "O3", "O4", "O5", "O6" };
				double[][] distances = new double[][] { 
				    { 0, 1, 9, 7, 11, 14 },
				    { 1, 0, 4, 3, 8, 10 }, 
				    { 9, 4, 0, 9, 2, 8 },
				    { 7, 3, 9, 0, 6, 13 }, 
				    { 11, 8, 2, 6, 0, 10 },
				    { 14, 10, 8, 13, 10, 0 }};


				ClusteringAlgorithm alg = new DefaultClusteringAlgorithm();
				// Cluster cluster = alg.performClustering(distances, names,   new AverageLinkageStrategy());
				
				
				 Cluster cluster = alg.performClustering(GlobalVars.distances, GlobalVars.geneSymbols, new AverageLinkageStrategy());
				
				
				 
				
				DendrogramPanel dp = new DendrogramPanel();
				dp.setModel(cluster);
				
				 
				JFrame frame= new JFrame(gc);	
				frame.setTitle("Hierarchial Clustering");
				frame.setSize(1200, 1000);
				frame.add(dp, BorderLayout.CENTER);
				frame.setVisible(true);
				
				
			 
				
				// Time consumed
				lblTimeConsumed.setText("Time consumed : "
						+ (System.currentTimeMillis() - timeConsumed) / 1000f
						+ " seconds ");
				
				

				
					
			
			}
		});
	

		//btnOriginalExpression = new Button(shell, SWT.RADIO);
		//btnOriginalExpression.setText("Original Expression");
		//btnOriginalExpression.setSelection(true);
		//btnOriginalExpression.setBounds(325, 12, 169, 16);

		//Button btnShiftedExpression = new Button(shell, SWT.RADIO);
		//btnShiftedExpression.setText("Shifted Expression");
		//btnShiftedExpression.setBounds(323, 47, 169, 16);

		//btnApclusteringlogalldata.setBounds(325, 92, 179, 16);
		//btnApclusteringlogalldata.setText("APClusteringLogAllData");
		
		//txtClusteredFilePath = new Text(shell, SWT.BORDER);
		//txtClusteredFilePath.setBounds(10, 375, 388, 20);
		//txtClusteredFilePath.setVisible(false);

	}
	
	
	protected void saveAllChartsAsFile(List lstClusteredFiles) {
		
		int ItemCount=lstClusteredFiles.getItemCount();
		String pathfileConnector= "/";
		
		if(OSinfo.isWindows()) {pathfileConnector="\\";  } // Windows, Linux, MacOS?
		
		for(int xx=0; xx<ItemCount; xx++)
		{
			String fileName=lstClusteredFiles.getItem(xx).toString();
			fileName=fileName.substring(fileName.lastIndexOf(pathfileConnector)+1).replace(".txt", "") ;
			
			
		 

		// Open file and get gene symbols
		String strGenes = Utilities.readFileByLines(lstClusteredFiles.getItem(xx).toString());

		// draw XY Lines
		XYSeriesCollection lineDataset = new XYSeriesCollection();
		String genesString = strGenes;
		genesString = genesString.replace('\n', ',');
		genesString = genesString.replace('\r', ',');
		genesString = genesString.replace('\t', ',');
		genesString = genesString.replace(' ', ',');
		genesString = genesString.replace(",,", ",");
		genesString = genesString.replace(",,", ",");

		String[] genesArray = genesString.split(","); // gene symbols
		XYSeries[] tsArraySeries = new XYSeries[genesArray.length];

		if (GlobalVars.geneSymbols == null) {
			MessageBox messageBox = new MessageBox(shell, SWT.OK | SWT.ICON_WARNING);
			messageBox.setMessage("Expression data have not been loaded.");
			messageBox.open();
			return;
		}

		for (int i = 0; i < genesArray.length; i++) {
			tsArraySeries[i] = new XYSeries(genesArray[i]);

			// data

			for (int j = 0; j < GlobalVars.geneSymbols.length; j++) {
				if (genesArray[i].equalsIgnoreCase(GlobalVars.geneSymbols[j])) {
					for (int k = 0; k < GlobalVars.pointCount; k++) {
						//if (btnOriginalExpression.getSelection()) {
							tsArraySeries[i].add(GlobalVars.timePoints[k],GlobalVars.originExpr[j][k]); // gene expression data
						//} else {
						//	tsArraySeries[i].add(k,GlobalVars.shiftedExpr[j][k]);
						//}

					}
					break;
				}
			}

			//
			lineDataset.addSeries(tsArraySeries[i]);
		}

		JFreeChart chart = ChartFactory.createXYLineChart(
				"Gene Expression, Cluster "+fileName, "Time("+ GlobalVars.TimeUnit  +")",
				"Expression", lineDataset,
				PlotOrientation.VERTICAL, true, true, true);
		// sub title
		TextTitle subtitle = new TextTitle("", new Font("",
				Font.BOLD, 12));
		chart.addSubtitle(subtitle);
		// main title
		chart.setTitle(new TextTitle("Gene Expression, Cluster "+fileName, new Font("",
				Font.ITALIC, 15)));
		chart.setAntiAlias(true);
		 chart.setBackgroundPaint(Color.WHITE);
		  XYPlot plot= chart.getXYPlot();
		 plot.setBackgroundPaint(Color.WHITE);
		chart.removeLegend();

		ChartFrame frame = new ChartFrame(
				"Gene Expression Graph", chart, true);
		frame.pack();
		
		saveAsFile(chart, lstClusteredFiles.getItem(xx).toString()+".png",707,452);
		
		 
		//

		/*
		 * MessageBox mBox=new MessageBox(shell);
		 * mBox.setMessage("OK"); mBox.open();
		 */
		}
	}
	
	
	 public static void saveAsFile(JFreeChart chart, String outputPath,  int width, int height) { 
	        FileOutputStream out = null;     
	        try {
	            File outFile = new File(outputPath);    

	            if (!outFile.getParentFile().exists()) {    
	                outFile.getParentFile().mkdirs(); 
	            }      

	            out = new FileOutputStream(outputPath);   
	            // 保存为PNG      

	            ChartUtilities.writeChartAsPNG(out, chart, width, height);   
	            // 保存为JPEG   
	            // ChartUtilities.writeChartAsJPEG(out, chart, weight, height); 

	            out.flush();    

	        } catch (FileNotFoundException e) {    

	            e.printStackTrace();     

	        } catch (IOException e) {   
	            e.printStackTrace();   

	        } finally {      
	            if (out != null) { 
	                try {  
	                    out.close(); 
	                } catch (IOException e) {     
	                    // do nothing      

	                }      

	            }      

	        }      

	    }      
}
