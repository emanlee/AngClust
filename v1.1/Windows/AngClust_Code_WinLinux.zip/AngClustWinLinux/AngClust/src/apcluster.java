import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class apcluster {

	public static int maxits = 1000;
	public static int convits = 100;
	public static double lam = 0.9f;
	public static boolean plt = false;
	public static boolean details = false;
	public static boolean nonoise = false;

	// apcluster(s,p,false,false,false,1000,false,100,false,0.9);
	public static int[] ap(double[][] s, double p, boolean Isdetails,
			boolean Isnonoise, boolean Ismaxits, int Maxits, boolean Isconvits,
			int Convits, boolean Isdampfact, double Dampfact) {
		// s should be a 2D matrix, s must have 3 columns or be square, (s - similarity)
		// s=rows*3columns (rowid1, rowid2, similarity)
		// p should be a vector or a scalar, p - a scalar
		// Maxits
		// Convits
		// Dampfact

		boolean logdata = Utilities.APClusteringLogAllData; // RiZhi JavaAPCLog.txt

		//logdata=true;
		
		FileWriter fw2 = null;

		if (logdata) {
			try {
				fw2 = new FileWriter(Utilities.DefaultFilePath()+ "JavaAPCLog.txt");
				fw2.append("\r\n");
				fw2.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		int[] idx = null;

		//
		int i = 1;
		if (Isdetails) {
			details = true;
		}
		if (Isnonoise) {
			nonoise = true;
		}
		if (Ismaxits) {
			maxits = Maxits;
		}
		if (Isconvits) {
			convits = Convits;
		}
		if (Isdampfact) {
			lam = Dampfact;
		}

		// Check that standard arguments are consistent in size
		if (maxits <= 0) {
			System.out.print("maxits must be a positive integer");
		}
		if (convits <= 0) {
			System.out.print("convits must be a positive integer");
		}
		if ((lam < 0.5) || (lam >= 1)) {  // Dampling factor
			System.out.print("dampfact must be >= 0.5 and < 1");
		}

		if (lam > 0.9) {  // Dampling factor
			System.out
					.print("Warning: Large damping factor in use. Turn on plotting\nto monitor the net similarity. The algorithm will\nchange decisions slowly, so consider using a larger value\nof convits.\n\n");
		}

		// Get sample size
		double n = 0;// sample size
		for (int j = 0; j < s.length; j++) {
			if (s[j][0] > n) {
				n = s[j][0];
			}
		}
		int N = (int) n;// sample size

		// Construct similarity matrix
		if (N > 5000) {  //  sample size < 5000
			System.out
					.print("Large memory request. Consider activating the sparse version of APCLUSTER.\n\n");
		}
		double[][] S = new double[N][N];
		for (int k = 0; k < s.length; k++) {
			S[(int) s[k][0] - 1][(int) s[k][1] - 1] = s[k][2]; // sub
																// index=0~N-1
		}

		//
		boolean symmetric = true;
		double realmin_ = Float.MIN_NORMAL;
		double realmax_ = Float.MAX_VALUE;

		// In case user did not remove degeneracies from the input similarities,
		// avoid degenerate solutions by adding a small amount of noise to the
		// input similarities
		if (!nonoise) {
			/*
			 * rns=randn('state'); randn('state',0);
			 * S=S+(eps*S+realmin_*100).*rand(N,N); randn('state',rns);
			 */
		}

		// Place preferences on the diagonal of S
		for (int l = 0; l < N; l++) {
			S[l][l] = p;
		}

		// Numerical stability -- replace -INF with -realmax
		boolean hasMinusINF = false;
		for (int l2 = 0; l2 < N; l2++) {
			for (int m = 0; m < N; m++) {
				if (S[l2][m] < -realmax_) {
					hasMinusINF = true;
					S[l2][m] = -realmax_;
				}
			}
		}
		if (hasMinusINF) {
			System.out
					.print("-INF similarities detected; changing to -REALMAX to ensure numerical stability");
		}

		boolean hasPlusINF = false;
		for (int l2 = 0; l2 < N; l2++) {
			for (int m = 0; m < N; m++) {
				if (S[l2][m] > realmax_) {
					hasPlusINF = true;
					S[l2][m] = realmax_;
				}
			}
		}
		if (hasPlusINF) {
			System.out
					.print("+INF similarities detected; change to a large positive value (but smaller than +REALMAX)");
		}

		// Allocate space for messages, etc
		double[] dS = new double[N];
		for (int m = 0; m < N; m++) {
			dS[m] = S[m][m];
		}

		double[][] A = new double[N][N];
		A = setzeros(A);
		double[][] R = new double[N][N];
		R = setzeros(R);
		int t = 1;

		/*
		 * if details idx=zeros(N,maxits+1); netsim=zeros(1,maxits+1);
		 * dpsim=zeros(1,maxits+1); expref=zeros(1,maxits+1); end;
		 */

		// Execute parallel affinity propagation updates
		int[][] e = new int[N][convits];
		for (int m = 0; m < N; m++) {
			for (int m2 = 0; m2 < convits; m2++) {
				e[m][m2] = 0;
			}
		}

		boolean dn = false;
		i = 0;

		double[][] ST = new double[N][N];
		if (symmetric) {
			ST = S; // saves memory if it's symmetric
		}
		double[] old = new double[N];

		double tempForAR;	//for A = transpose(A);	R = transpose(R);
		double[] Rp = new double[N];
		int[] E = new int[N];
		int[] se = new int[N];
		double[] AS = new double[N];
		while (!dn) {
			i = i + 1;
			// System.out.println("i=" +String.valueOf(i) );
			// Compute responsibilities
			
			// A = transpose(A);	R = transpose(R);					
			for (int k2 = 0; k2 < N; k2++) {
				for (int k4 = 0; k4 < k2; k4++) {
					tempForAR=A[k2][k4]; A[k2][k4]= A[k4][k2];A[k4][k2]=tempForAR;
					tempForAR=R[k2][k4]; R[k2][k4]= R[k4][k2];R[k4][k2]=tempForAR;					 
				}
			}
	 
			 
		
			for (int ii = 0; ii < N; ii++) {				
				double Y = -realmax_; //Max of AS
				int I = 0;				
				for (int j = 0; j < N; j++) {
					// old = getOneColumn(R, ii);
					old[j] = R[j][ii];	
					// AS = matrixAddMatrix(getOneColumn(A, ii), getOneColumn(ST, ii));
					AS[j] = A[j][ii] + ST[j][ii];
					if (AS[j] > Y) {
						Y = AS[j];
						I = j;
					}
				}
	
				AS[I] = -realmax_;

				double Y2 = -realmax_; //SubMax of AS
				// setOneColumn(R, ii, (matrixSubtractANumber(getOneColumn(ST, ii), Y)));
				for (int j = 0; j < N; j++) {
					if (AS[j] > Y2) {
						Y2 = AS[j];
					}
					R[j][ii] = ST[j][ii] - Y;					
				}				 

				R[I][ii] = ST[I][ii] - Y2;
				/*
				 * double[] tmp_1_lam = matrixMultiplyANumber( getOneColumn(R,
				 * ii), 1 - lam); double[] tmp_old_lam =
				 * matrixMultiplyANumber(old, lam); setOneColumn(R, ii,
				 * matrixAddMatrix(tmp_1_lam, tmp_old_lam));
				 */

				for (int j = 0; j < N; j++) {
					R[j][ii] = R[j][ii] * (1 - lam) + old[j] * lam;
					if (R[j][ii] > realmax_) {
						R[j][ii] = realmax_;
					}
				}

			}

			// A=A'; R=R';
			//A = transpose(A);
			//R = transpose(R);
			 		
			for (int k2 = 0; k2 < N; k2++) {
				for (int k4 = 0; k4 < k2; k4++) {
					tempForAR=A[k2][k4]; A[k2][k4]= A[k4][k2];A[k4][k2]=tempForAR;
					tempForAR=R[k2][k4]; R[k2][k4]= R[k4][k2];R[k4][k2]=tempForAR;					 
				}
			}

			if (logdata) {
				try {
					fw2 = new FileWriter(Utilities.DefaultFilePath()
							+ "JavaAPCLog.txt", true);
					fw2.append(String.valueOf(i) + " ===111 A=== \r\n");
					for (int i5 = 0; i5 < 3; i5++) {

						fw2.append(String.valueOf(A[i5][0]) + "\t"
								+ String.valueOf(A[i5][1]) + "\t"
								+ String.valueOf(A[i5][2]) + "\r\n");
					}
					fw2.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

				try {
					fw2 = new FileWriter(Utilities.DefaultFilePath()
							+ "JavaAPCLog.txt", true);
					fw2.append(String.valueOf(i) + " ===111 R===== \r\n");
					for (int i5 = 0; i5 < 3; i5++) {

						fw2.append(String.valueOf(R[i5][0]) + "\t"
								+ String.valueOf(R[i5][1]) + "\t"
								+ String.valueOf(R[i5][2]) + "\r\n");
					}

					fw2.close();
				} catch (IOException e1) {

					e1.printStackTrace();
				}
			}

			// Compute availabilities
			
			for (int jj = 0; jj < N; jj++) {
				
				// old = getOneColumn(A, jj);
				double sumOfRp =0;
				for (int j = 0; j < N; j++) {
					old[j] = A[j][jj];
					if (R[j][jj] > 0) {
						Rp[j] = R[j][jj];
						sumOfRp+=R[j][jj];
					} else {
						Rp[j] = 0;
					}
					
				}			
				sumOfRp=sumOfRp-Rp[jj]+ R[jj][jj];
				Rp[jj] = R[jj][jj];
				/*
				 * setOneColumn( A, jj,
				 * matrixSubtractANumber(matrixMultiplyANumber(Rp, -1),
				 * -matrixSumAllElement(Rp)));
				 */
				//double sumOfRp = matrixSumAllElement(Rp);
				for (int j = 0; j < N; j++) {
					A[j][jj] = -Rp[j] + sumOfRp;
				}

				double dA = A[jj][jj];
				for (int j = 0; j < N; j++) {
					if (A[j][jj] >= 0) {
						A[j][jj] = 0;
					}
					if (j==jj) {
						A[jj][jj] = dA;
					}
					A[j][jj] = A[j][jj] * (1 - lam) + old[j] * lam;
				}
				
				/*
				 * setOneColumn( A, jj, matrixAddMatrix(
				 * matrixMultiplyANumber(getOneColumn(A, jj), 1 - lam),
				 * matrixMultiplyANumber(old, lam)));
				 */
				 

			} // Damping

			if (logdata) {
				try {
					fw2 = new FileWriter(Utilities.DefaultFilePath()
							+ "JavaAPCLog.txt", true);
					fw2.append(String.valueOf(i) + " ===222 A=== \r\n");
					for (int i5 = 0; i5 < 3; i5++) {

						fw2.append(String.valueOf(A[i5][0]) + "\t"
								+ String.valueOf(A[i5][1]) + "\t"
								+ String.valueOf(A[i5][2]) + "\r\n");
					}

					fw2.close();
				} catch (IOException e1) {

					e1.printStackTrace();
				}

				try {
					fw2 = new FileWriter(Utilities.DefaultFilePath()
							+ "JavaAPCLog.txt", true);
					fw2.append(String.valueOf(i) + " ===222 R===== \r\n");
					for (int i5 = 0; i5 < 3; i5++) {

						fw2.append(String.valueOf(R[i5][0]) + "\t"
								+ String.valueOf(R[i5][1]) + "\t"
								+ String.valueOf(R[i5][2]) + "\r\n");
					}

					fw2.close();
				} catch (IOException e1) {

					e1.printStackTrace();
				}
			}

			// Check for convergence
			int e_column = (i - 1) % convits + 1 - 1;
			int K =0; //sum of E
			for (int m = 0; m < N; m++) {
				if (A[m][m] + R[m][m] > 0) {
					E[m] = 1;
					K++;
				} else {
					E[m] = 0;
				}
				e[m][e_column] = E[m];
			}		
			// setOneColumn(e, e_column, E);
		
			
			if (i >= convits || i >= maxits) {

				boolean unconverged = false;
				int sum_2 = 0;
				for (int o = 0; o < N; o++) {
					int sum = 0;
					for (int q = 0; q < e[0].length; q++) {
						sum += e[o][q];
					}
					se[o] = sum;
					if (se[o] == convits || se[o] == 0) {
						sum_2 += 1;
					}
				 
				}
				
			
				if (sum_2 != N) {
					unconverged = true;
				} else {
					unconverged = false;
				}
				if ((!unconverged && K > 0) || (i == maxits)) {
					dn = true;

				}
			}

			// write A,R to a txt file.
			FileWriter fw = null;

			if (logdata) {
				try {
					fw = new FileWriter(Utilities.DefaultFilePath()
							+ "JavaAPCLog.txt", true);
					fw.append(String.valueOf(i) + " ===333 A==== \r\n");
					for (int i5 = 0; i5 < 3; i5++) {

						fw.append(String.valueOf(A[i5][0]) + "\t"
								+ String.valueOf(A[i5][1]) + "\t"
								+ String.valueOf(A[i5][2]) + "\r\n");
					}

					fw.close();
				} catch (IOException e1) {

					e1.printStackTrace();
				}

				try {
					fw2 = new FileWriter(Utilities.DefaultFilePath()
							+ "JavaAPCLog.txt", true);
					fw2.append(String.valueOf(i) + " ===333 R===== \r\n\n\n");
					for (int i5 = 0; i5 < 3; i5++) {

						fw2.append(String.valueOf(R[i5][0]) + "\t"
								+ String.valueOf(R[i5][1]) + "\t"
								+ String.valueOf(R[i5][2]) + "\r\n");
					}

					fw2.close();
				} catch (IOException e1) {

					e1.printStackTrace();
				}

			}
		}

		// Handle plotting and storage of details, if requested

		// I=find((diag(A)+diag(R))>0); K=length(I);
		int[] pre_I = new int[N]; // Identify exemplars
		int K = 0;
		for (int o = 0; o < N; o++) {
			if (A[o][o] + R[o][o] > 0) {
				pre_I[K] = o;
				K++;
			}
		}
		int[] I = new int[K];
		for (int q = 0; q < I.length; q++) {
			I[q] = pre_I[q];
		}

		if (K > 0) {
			double[][] SI = new double[N][K];
			for (int j = 0; j < SI.length; j++) {
				for (int j2 = 0; j2 < K; j2++) {
					SI[j][j2] = S[j][I[j2]];
				}
			}
			// [tmp c]=max(S(:,I),[],2);
			int[] c = new int[N];
			for (int j = 0; j < SI.length; j++) {
				double tmpMax = -realmax_;
				for (int j2 = 0; j2 < K; j2++) {
					if (SI[j][j2] > tmpMax) {
						tmpMax = SI[j][j2];
						c[j] = j2;
					}

				}
			}
			// % Identify clusters % Refine the
			// final set of exemplars and clusters and return results for k=1:K
			// c(I)=1:K;
			for (int j = 0; j < I.length; j++) {
				c[I[j]] = j;
			}

			//
			for (int k = 0; k < K; k++) {
				// ii=find(c==k);
				int[] ii = matrixFind(c, k);
				// [y j]=max(sum(S(ii,ii),1));
				double[][] S_ii_ii = new double[ii.length][ii.length];
				for (int j = 0; j < ii.length; j++) {
					for (int j2 = 0; j2 < ii.length; j2++) {
						S_ii_ii[j][j2] = S[ii[j]][ii[j2]];
					}
				}
				double[] Sum_S_ii_ii = matrixSumColumns(S_ii_ii);
				double tmpMax = -realmax_;
				int j = 0;
				for (int j3 = 0; j3 < Sum_S_ii_ii.length; j3++) {
					if (Sum_S_ii_ii[j3] > tmpMax) {
						tmpMax = Sum_S_ii_ii[j3];
						j = j3;
					}
				}
				I[k] = ii[j]; // I(k)=ii(j(1));

			}

			// notI=reshape(setdiff(1:N,I),[],1);
			int[] pre_notI = new int[N];
			int k4 = 0;
			for (int j = 0; j < N; j++) {
				boolean found = false;
				for (int j2 = 0; j2 < I.length; j2++) {
					if (I[j2] == j) {
						found = true;
						break;
					}
				}

				if (!found) {
					pre_notI[k4] = j;
					k4++;
				}
			}
			int[] notI = new int[k4];
			for (int j = 0; j < notI.length; j++) {
				notI[j] = pre_notI[j];
			}

			// [tmp c]=max(S(:,I),[],2); c(I)=1:K;

			for (int j = 0; j < SI.length; j++) {
				for (int j2 = 0; j2 < K; j2++) {
					SI[j][j2] = S[j][I[j2]];
				}
			}

			for (int j = 0; j < SI.length; j++) {
				double tmpMax = -realmax_;
				for (int j2 = 0; j2 < K; j2++) {
					if (SI[j][j2] > tmpMax) {
						tmpMax = SI[j][j2];
						c[j] = j2;
					}

				}
			}
			// c(I)=1:K;
			for (int j = 0; j < I.length; j++) {
				c[I[j]] = j;
			}

			// tmpidx=I(c);
			int[] tmpidx = new int[c.length];
			for (int j = 0; j < tmpidx.length; j++) {
				tmpidx[j] = I[c[j]];
			}

			idx = tmpidx;

			if (logdata) {
				try {
					fw2 = new FileWriter(Utilities.DefaultFilePath()
							+ "JavaAPCLog.txt", true);
					fw2.append(" ======== \r\n\n\n");
					for (int j = 0; j < tmpidx.length; j++) {

						fw2.append(String.valueOf(tmpidx[j]) + "\r\n");
					}

					fw2.close();
				} catch (IOException e1) {

					e1.printStackTrace();
				}

			}
		}

		return idx;

	}

	public static double[][] transpose(double[][] m) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		double[][] t = new double[rowCount][columnCount];
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				t[i][j] = m[j][i];
			}
		}
		return t;
	}

	public static double[][] setzeros(double[][] m) {
		int rowCount = m.length;
		int columnCount = m[0].length;

		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				m[i][j] = 0;
			}
		}
		return m;
	}

	public static double[] getOneColumn(double[][] m, int c) {
		int rowCount = m.length;
		double[] t = new double[rowCount];
		for (int i = 0; i < rowCount; i++) {
			t[i] = m[i][c];
		}
		return t;
	}

	public static double[][] setOneColumn(double[][] m, int c, double[][] newm) {
		int rowCount = m.length;
		int columnCount = m[0].length;

		for (int i = 0; i < rowCount; i++) {
			m[i][c] = newm[i][0];
		}
		return m;
	}

	public static double[][] setOneColumn(double[][] m, int c, double[] newm) {
		int rowCount = m.length;
		for (int i = 0; i < rowCount; i++) {
			m[i][c] = newm[i];
		}
		return m;
	}

	public static int[][] setOneColumn(int[][] m, int c, int[][] newm) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		for (int i = 0; i < rowCount; i++) {
			m[i][c] = newm[i][0];
		}
		return m;
	}

	public static int[][] setOneColumn(int[][] m, int c, int[] newm) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		for (int i = 0; i < rowCount; i++) {
			m[i][c] = newm[i];
		}
		return m;
	}

	public static double[][] matrixSubtractANumber(double[][] m, double c) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		double[][] t = new double[rowCount][columnCount];
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				t[i][j] = m[i][j] - c;
			}
		}
		return t;
	}

	public static double[] matrixSubtractANumber(double[] m, double c) {
		int rowCount = m.length;
		double[] t = new double[rowCount];
		for (int i = 0; i < rowCount; i++) {
			t[i] = m[i] - c;
		}
		return t;
	}

	public static double[] matrixSumColumns(double[][] m) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		double[] t = new double[columnCount];

		for (int j = 0; j < columnCount; j++) {
			t[j] = 0;
			for (int i = 0; i < rowCount; i++) {
				t[j] += m[i][j];
			}
		}
		return t;
	}

	public static double[][] matrixAddMatrix(double[][] m, double c[][]) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		double[][] t = new double[rowCount][columnCount];
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				t[i][j] = m[i][j] + c[i][j];
			}
		}
		return t;
	}

	public static double[] matrixAddMatrix(double[] m, double c[]) {
		int rowCount = m.length;
		double[] t = new double[rowCount];
		for (int i = 0; i < rowCount; i++) {
			t[i] = m[i] + c[i];
		}
		return t;
	}

	public static double[][] matrixMultiplyANumber(double[][] m, double c) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		double[][] t = new double[rowCount][columnCount];
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				t[i][j] = m[i][j] * c;
			}
		}
		return t;
	}

	public static double[] matrixMultiplyANumber(double[] m, double c) {
		int rowCount = m.length;
		double[] t = new double[rowCount];
		for (int i = 0; i < rowCount; i++) {
			t[i] = m[i] * c;
		}
		return t;
	}

	public static int[][] matrixFind(double[][] m, double c) {
		// m=n rows*1 column
		int rowCount = m.length;
		int columnCount = m[0].length;
		int[][] t = new int[rowCount][1];
		int k = 0;
		for (int i = 0; i < rowCount; i++) {
			if (m[i][0] == c) {
				t[k][0] = i;
				k++;
			}
		}
		int[][] newt = new int[k][1];
		for (int i = 0; i < newt.length; i++) {
			newt[i][0] = t[i][0];
		}
		return newt;
	}

	public static int[] matrixFind(int[] m, int c) {
		// m=n rows*1 column
		int rowCount = m.length;

		int[] t = new int[rowCount];
		int k = 0;
		for (int i = 0; i < rowCount; i++) {
			if (m[i] == c) {
				t[k] = i;
				k++;
			}
		}
		int[] newt = new int[k];
		for (int i = 0; i < newt.length; i++) {
			newt[i] = t[i];
		}
		return newt;
	}

	public static double matrixSumAllElement(double[][] m) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		double sum = 0;
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				sum += m[i][j];
			}
		}
		return sum;
	}

	public static int matrixSumAllElement(int[] m) {
		int rowCount = m.length;
		int sum = 0;
		for (int i = 0; i < rowCount; i++) {
			sum += m[i];
		}
		return sum;
	}

	public static double matrixSumAllElement(double[] m) {
		int rowCount = m.length;
		double sum = 0;
		for (int i = 0; i < rowCount; i++) {
			sum += m[i];
		}
		return sum;
	}

	public static int matrixSumAllElement(int[][] m) {
		int rowCount = m.length;
		int columnCount = m[0].length;
		int sum = 0;
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				sum += m[i][j];
			}
		}
		return sum;
	}

	public static int median(int b[]) {
		int temp, i, j, dct;
		temp = b.length;
		int[] a = new int[temp];
		for (int k = 0; k < a.length; k++) {
			a[k] = b[k];
		}

		for (i = temp - 1; i > 0; i--) {
			for (j = 0; j < i; j++)
				if (a[j] > a[j + 1]) {
					dct = a[j];
					a[j] = a[j + 1];
					a[j + 1] = dct;
				}
		}
		if (temp % 2 == 1)
			return a[(temp - 1) / 2];
		else
			return a[temp / 2];

	}

	public static double median(double b[]) {
		int temp, i, j;
		double dct;

		temp = b.length;
		double[] a = new double[temp];
		for (int k = 0; k < a.length; k++) {
			a[k] = b[k];
		}

		for (i = temp - 1; i > 0; i--) {
			for (j = 0; j < i; j++)
				if (a[j] > a[j + 1]) {
					dct = a[j];
					a[j] = a[j + 1];
					a[j + 1] = dct;
				}
		}
		if(temp==2)
			return (b[0]+b[1])/2;
		
		
		if (temp % 2 == 1)
			return a[(temp - 1) / 2];
		else
			return a[temp / 2];

	}

	public static double median_for_apcluster(double b[][]) {
		int temp;
		temp = b.length;
		double[] a = new double[temp];
		for (int k = 0; k < a.length; k++) {
			a[k] = b[k][2];
		}

		Arrays.sort(a);

		if (temp % 2 == 1)
			return a[(temp - 1) / 2];
		else
			return (a[temp / 2] + a[temp / 2 - 1]) / 2; // same to Matlab

	}
	
	public static double median(double b[][],int columnIndex) {
		int temp;
		temp = b.length;
		double[] a = new double[temp];
		for (int k = 0; k < a.length; k++) {
			a[k] = b[k][columnIndex];
		}

		Arrays.sort(a);

		if (temp % 2 == 1)
			return a[(temp - 1) / 2];
		else
			return (a[temp / 2] + a[temp / 2 - 1]) / 2; // same to Matlab

	}

}
