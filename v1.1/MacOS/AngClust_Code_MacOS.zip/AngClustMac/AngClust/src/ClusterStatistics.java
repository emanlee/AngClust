import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Vector;

import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;


public class ClusterStatistics {

	protected Shell shell;
	private Text txtFolderPath;
	private Table table;
	private Vector tableRows=null;
	private String myfileName="";

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			ClusterStatistics window = new ClusterStatistics();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(710+15, 416+30+30+30+10);
		shell.setText("Cluster Statistics (Feature: angles)");
		int width=shell.getDisplay().getBounds().width; // �ҵ�createContents����������õ���Ļ�Ŀ�ȡ�
		int height=shell.getDisplay().getBounds().height; // ����������У��õ���Ļ�ĸ߶ȡ�
		// �õ���Ļ�Ŀ�߶ȼ�ȥshell���ڵĿ�Ⱥ͸߶ȣ�����2�õ����ڵ����Ͻ����ꡣ
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
	
		int buttonSizeHeight=23;
		
		Label lblExportToDatatabletxt = new Label(shell, SWT.NONE);
		lblExportToDatatabletxt.setBounds(30+82, 352+30+30+30+5, 276+200, 23);
		lblExportToDatatabletxt.setText("."); 
		
		final Label lblClustercount = new Label(shell, SWT.NONE);
		lblClustercount.setBounds(10, 59, 176, 12);
		lblClustercount.setText("Cluster count");

		Label lblNumOfGene = new Label(shell, SWT.NONE);
		lblNumOfGene.setBounds(10, 10, 537, 19);
		lblNumOfGene
				.setText("Number of gene, Average of correlation coefficient, Average of euclidean, Fuctuation");

		txtFolderPath = new Text(shell, SWT.BORDER);
		txtFolderPath.setBounds(10, 35, 503+60, 18);
		final List lstClusteredGenes = new List(shell, SWT.BORDER
				| SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI);
		lstClusteredGenes.setBounds(10, 89, 206, 257+30+30+30+5);

		Button btnBrowse = new Button(shell, SWT.NONE);
		btnBrowse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				// folder
				DirectoryDialog folderdlg = new DirectoryDialog(shell);
				folderdlg.setText("Select folder");
				//folderdlg.setFilterPath("SystemDrive");
				folderdlg.setFilterPath(Utilities.DefaultFilePath());
				
				if(OSinfo.isWindows()) { GlobalVars.pathfileConnector="\\"; GlobalVars.lineEnd="\r\n";  } // Windows, Linux, MacOS?

				
				 
				folderdlg.setMessage("Please select the clusters folder");
				String selecteddir = folderdlg.open();
				if (selecteddir == null) {
					return;
				} else {
					txtFolderPath.setText(selecteddir);
				}

				// Load file names
				int fileCount = 0;
				File file2 = new File(selecteddir + GlobalVars.pathfileConnector);
				if (file2.isDirectory()) {
					String[] filelist = file2.list((file, name) -> name.endsWith(".txt"));
					fileCount = filelist.length;
					lblClustercount.setText("Cluster count: "
							+ String.valueOf(filelist.length));
					for (int i = 0; i < filelist.length; i++) {
						File readfile = new File(selecteddir + GlobalVars.pathfileConnector+ filelist[i]);
						if (!readfile.isDirectory()) {
							lstClusteredGenes.add(readfile.getPath());

						}
					}
				}

				// 1index , 2 ID, 3 Num of Gene, 4 Average of Correlation
				// Coefficient,
				// 5 Average of Euclidean, 6 Fluctuation
				double[][] Statistic = new double[fileCount][6];
				for (int i6 = 0; i6 < lstClusteredGenes.getItemCount(); i6++) {
					String fullFileNameString = lstClusteredGenes.getItem(i6)
							.toString();
					String tmpID = fullFileNameString.substring(
							fullFileNameString.lastIndexOf(GlobalVars.pathfileConnector) + 1,
							fullFileNameString.lastIndexOf(".") );
					Statistic[i6][0] = i6 + 1;
					Statistic[i6][1] = Integer.valueOf(tmpID); // Exception in thread "main" java.lang.NumberFormatException: For input string: "117.txt"

					// Open file and get gene symbols
					String strGenes = Utilities
							.readFileByLines(lstClusteredGenes.getItem(i6)
									.toString());

					//
					String genesString = strGenes;
					genesString = genesString.replace('\n', ',');
					genesString = genesString.replace('\r', ',');
					genesString = genesString.replace('\t', ',');
					genesString = genesString.replace(' ', ',');
					genesString = genesString.replace(",,", ",");
					genesString = genesString.replace(",,", ",");

					String[] genesArray = genesString.split(",");

					int GeneCount = genesArray.length;
					Statistic[i6][2] = GeneCount;
					// Get cluster center
					// Get original expression from GlobalVars.originExpr
					double[][] originalExpressions = new double[GeneCount][GlobalVars.pointCount];

					// merge local angles and global angles
					double[][] mergedAngles = new double[GeneCount][2 * GlobalVars.pointCount - 2];

					// must run load , run similarity
					for (int i = 0; i < GeneCount; i++) {
						for (int j = 0; j < GlobalVars.geneSymbols.length; j++) {
							if (genesArray[i]
									.equalsIgnoreCase(GlobalVars.geneSymbols[j])) {
								originalExpressions[i] = Arrays.copyOf(
										GlobalVars.originExpr[j],
										GlobalVars.pointCount);
								for (int j4 = 0; j4 < GlobalVars.pointCount - 1; j4++) {
									mergedAngles[i][j4] = GlobalVars.LocalAnglesTwoAdjacentPoints[j][j4];
									mergedAngles[i][j4 + GlobalVars.pointCount
											- 1] = GlobalVars.GlobalAnglesEveryTimePoint[j][j4];
								}
								break;
							}
						}

						//

					}

					// Get Euclidean distance
					double[][] EuclideanMatrix = new double[GeneCount][GeneCount];
					double euclideanSum = 0;
					int temp_count = 0;
					for (int i = 0; i < GeneCount; i++) {
						for (int j = 0; j <= i; j++) {
							if (i != j) {
								temp_count++;
								double tmp_sum = 0;
								for (int k = 0; k < GlobalVars.pointCount; k++) {
									tmp_sum += (originalExpressions[i][k] - originalExpressions[j][k])
											* (originalExpressions[i][k] - originalExpressions[j][k]);
								}
								EuclideanMatrix[i][j] = Math.sqrt(tmp_sum);
								EuclideanMatrix[j][i] = EuclideanMatrix[i][j];
								euclideanSum += EuclideanMatrix[j][i];
							} else {
								EuclideanMatrix[i][j] = 0;
							}

						}
					}
					double averageEuclidean = euclideanSum / temp_count;
					Statistic[i6][4] = averageEuclidean;

					// Get cluster centroid, original expression
					double[] clusterCenter = new double[GlobalVars.pointCount];
					String s_temp = "";
					for (int i = 0; i < GlobalVars.pointCount; i++) {
						clusterCenter[i] = apcluster.median(
								originalExpressions, i);
						s_temp += String.valueOf(clusterCenter[i]) + " ";
					}

					// Get center gene
					double minEuclideanDistance = 1000000;
					int centerGeneIndex = 0;
					for (int i = 0; i < GeneCount; i++) {

						double tmp_sum = 0;
						for (int k = 0; k < GlobalVars.pointCount; k++) {
							tmp_sum += (originalExpressions[i][k] - clusterCenter[k])
									* (originalExpressions[i][k] - clusterCenter[k]);
						}
						if (Math.sqrt(tmp_sum) < minEuclideanDistance) {
							minEuclideanDistance = Math.sqrt(tmp_sum);
							centerGeneIndex = i;
						}
					}

					// Fluctuation
					double tmpMinExpress = 100000;
					double tmpMaxExpress = -100000;
					for (int i = 0; i < GlobalVars.pointCount; i++) {
						if (originalExpressions[centerGeneIndex][i] < tmpMinExpress) {
							tmpMinExpress = originalExpressions[centerGeneIndex][i];
						}
						if (originalExpressions[centerGeneIndex][i] > tmpMaxExpress) {
							tmpMaxExpress = originalExpressions[centerGeneIndex][i];
						}
					}
					Statistic[i6][5] = tmpMaxExpress - tmpMinExpress;

					// Get correlation coefficient
					PearsonsCorrelation p = new PearsonsCorrelation();
					double correlationSum = 0;
					int temp_correlationCount = 0;
					double[][] SimilarityMatrix = new double[GeneCount][GeneCount];
					for (int i = 0; i < GeneCount; i++) {
						for (int j = 0; j <= i; j++) {
							if (i != j) {

								temp_correlationCount++;
								SimilarityMatrix[i][j] = p.correlation(
										mergedAngles[i], mergedAngles[j]);
								SimilarityMatrix[j][i] = SimilarityMatrix[i][j];
								correlationSum += SimilarityMatrix[i][j];
							} else {
								SimilarityMatrix[i][j] = 1;
							}

						}
					}
					double averageCorrelation = correlationSum
							/ temp_correlationCount;
					Statistic[i6][3] = averageCorrelation;

				}

				// 1index , 2 ID, 3 Num of Gene, 4 Average of Correlation
				// Coefficient,
				// 5 Average of Euclidean, 6 Fluctuation
				// display in the table
				Vector vHeader = new Vector();
				vHeader.add("Index");
				vHeader.add("ID");
				vHeader.add("#Gene");
				vHeader.add("Avg Corre");
				vHeader.add("Avg Eucl");
				vHeader.add("Fluctuation");
				
				
				DecimalFormat df = new DecimalFormat("#.####");
			  

				Vector vRows = new Vector();
				for (int i = 0; i < Statistic.length; i++) {
					Vector vrow = new Vector();
				 
					 
					vrow.add(Integer.parseInt(new java.text.DecimalFormat("0").format(Statistic[i][0])) );
					vrow.add(Integer.parseInt(new java.text.DecimalFormat("0").format(Statistic[i][1])) );
					vrow.add(Integer.parseInt(new java.text.DecimalFormat("0").format(Statistic[i][2])) );
					
					vrow.add(df.format(Statistic[i][3]));
					vrow.add(df.format(Statistic[i][4]));
					vrow.add(df.format(Statistic[i][5]));
					vRows.add(vrow);
				}
				
				tableRows=vRows;

				for (int i = 0; i < vHeader.size(); i++) {
					TableColumn tableColumn = new TableColumn(table, SWT.NONE);
					tableColumn.setText(vHeader.elementAt(i).toString());
					tableColumn.setWidth(80);
				}
				for (int i = 0; i < vRows.size(); i++) {
					Vector v = (Vector) (vRows.elementAt(i));
					String[] stringArray = new String[v.size()];
					for (int index = 0; index < v.size(); index++) {
						stringArray[index] = String.valueOf(v.get(index));
					}

					TableItem tableItem = new TableItem(table, 0);
					tableItem.setText(stringArray);
				}

				System.out.println();

			}
		});
		btnBrowse.setBounds(528+60, 33, 72, 22);
		btnBrowse.setText("Browse ...");

		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(231, 59+5, 461, 317+30+30);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		
		Button btnExport = new Button(shell, SWT.NONE);
		btnExport.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				FileWriter fw = null;
				try {
					myfileName=Utilities.DefaultFilePath()+GlobalVars.pathfileConnector+"clusterstatistics.txt";
					fw = new FileWriter(myfileName);
					fw.write("Index\tID\t#Gene\tAvg Corre\tAvg Eucli\tFluctuation\r\n");
					
					for (int i = 0; i < tableRows.size(); i++) {
						Vector vrow=(Vector)tableRows.elementAt(i);
						
						fw.write(String.valueOf(vrow.get(0)) +"\t"+String.valueOf(vrow.get(1))  +"\t"
								+String.valueOf(vrow.get(2)) +"\t"+String.valueOf(vrow.get(3)) +"\t"
								+String.valueOf(vrow.get(4)) +"\t"+String.valueOf(vrow.get(5))  
								+ GlobalVars.lineEnd);
					}
					fw.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				lblExportToDatatabletxt.setText("Export to "+myfileName);
				
				
			}
		});
		btnExport.setBounds(30, 352+30+30+30+5, 72, 22);
		btnExport.setText("Export");
		
	
		
		
		Button btnCurrentClustering = new Button(shell, SWT.NONE);
		btnCurrentClustering.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				txtFolderPath.setText(GlobalVars.clusterFilesPath);
				
			}
		});
		btnCurrentClustering.setBounds(553, 7, 123, 22);
		btnCurrentClustering.setText("Current Clustering");

	}
}
