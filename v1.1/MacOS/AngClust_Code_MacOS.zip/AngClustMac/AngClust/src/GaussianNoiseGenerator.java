
public class GaussianNoiseGenerator {
	
	
	public static void main(String[] args) {
		
		//double variance=1;  // 3%, 5%, 10% (  absolute(gene expression)*3% )
		//double mean=0;		
		for(int ii=0; ii<100; ii++)
		{			 
			System.out.println(generate(1,0));			
		}		
	 
	}
	
	
	public static double generate(double variance, double mean)
	{
		// Gaussian Noise
		//double variance=1;  // 3%, 5%, 10% (  absolute(gene expression)*3% )
		//double mean=0;		
	 
		java.util.Random r = new java.util.Random();
		return  r.nextGaussian() * Math.sqrt(variance) + mean;	
		
	}
	

}
