import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.apache.commons.math3.stat.correlation.*;
import org.eclipse.swt.widgets.Label;
import com.fastdtw.dtw.FastDTW;
import com.fastdtw.timeseries.TimeSeries;
import com.fastdtw.timeseries.TimeSeriesBase;
import com.fastdtw.timeseries.TimeSeriesBase.Builder;
import com.fastdtw.util.Distances;


/*   */
public class SimilarityMatrix {

	protected Shell shell;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			SimilarityMatrix window = new SimilarityMatrix();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(530, 400);
		shell.setText("Features and Similarity");
		int width=shell.getDisplay().getBounds().width; // �ҵ�createContents����������õ���Ļ�Ŀ�ȡ�
		int height=shell.getDisplay().getBounds().height; // ����������У��õ���Ļ�ĸ߶ȡ�
		// �õ���Ļ�Ŀ�߶ȼ�ȥshell���ڵĿ�Ⱥ͸߶ȣ�����2�õ����ڵ����Ͻ����ꡣ
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
		
		int buttonSizeHeight=24;
		
		
		// Features
		Group grpFeatures = new Group(shell, SWT.NONE);
		grpFeatures.setText("Features");
		grpFeatures.setBounds(26, 121-111, 286, 124);

		final Button btnEuclideanOrCorrelation = new Button(grpFeatures, SWT.RADIO);
		btnEuclideanOrCorrelation.setBounds(10, 31, 246, buttonSizeHeight);
		btnEuclideanOrCorrelation.setText("Gene Expression Values");
		
		final Button btnLocalAnglestwo = new Button(grpFeatures, SWT.RADIO);
		btnLocalAnglestwo.setSelection(true);
		btnLocalAnglestwo.setBounds(10, 69, 246+8, 16);
		btnLocalAnglestwo.setText("Angles");		
	
				

		// SimilarityMeasurement
		Group grpSimilarityMeasurement = new Group(shell, SWT.NONE);
		grpSimilarityMeasurement.setText("Similarity Measurement");
		grpSimilarityMeasurement.setBounds(26, 10+161, 286, 85+40);
		
		final Button btnEuclideanDistance = new Button(grpSimilarityMeasurement,
				SWT.RADIO);
		btnEuclideanDistance.setBounds(10, 20 , 198, buttonSizeHeight);
		btnEuclideanDistance.setText("Euclidean Distance");

		Button btnPearsonCorrelatedCoefficient = new Button(
				grpSimilarityMeasurement, SWT.RADIO);
		btnPearsonCorrelatedCoefficient.setSelection(true);
		btnPearsonCorrelatedCoefficient
				.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
					}
				});
		btnPearsonCorrelatedCoefficient.setBounds(10, 50 , 246, buttonSizeHeight);
		btnPearsonCorrelatedCoefficient
				.setText("Pearson Correlation Coefficient");

		
		final Button btnDTW = new Button(grpSimilarityMeasurement,
				SWT.RADIO);
		btnDTW.setBounds(10, 80 , 198, buttonSizeHeight);
		btnDTW.setText("Dynamic Time Warping");

		
		final Label lblMessage = new Label(shell, SWT.NONE);
		lblMessage.setBounds(26, 261+55, 400, buttonSizeHeight);
		lblMessage.setText(" - ");
		
		final	Label lblPathFileOfSimilarityMatrix = new Label(shell, SWT.NONE);
		lblPathFileOfSimilarityMatrix.setText(" - ");
		lblPathFileOfSimilarityMatrix.setBounds(26, 251+22+50+15, 456, 50);

		
		
		// button OK
		Button btnOk = new Button(shell, SWT.NONE);
		btnOk.setBounds(360-20, 134, 150, buttonSizeHeight);
		btnOk.setText("Calculate Similarity");
		btnOk.setToolTipText("Calculate similarity.");
		
			
		// button close
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setText("Close");
		button.setBounds(360-20, 218, 150, buttonSizeHeight);
		
		// button Save
		// save to similarity.txt
		Button btnSave = new Button(shell, SWT.NONE);
		btnSave.setBounds(360-20, 177, 150, buttonSizeHeight);
		btnSave.setText("Save");
		btnSave.setToolTipText("Save similarity to similarity.txt");
		btnSave.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				if(GlobalVars.pointCount==0)
				{
					
					MessageBox messageBox =
						    new MessageBox(shell,
						     SWT.OK|
						     SWT.ICON_WARNING);
						messageBox.setMessage("Gene expression was not loaded.");
						messageBox.open(); 		
						return;
					
				}
				
				
				// 
				FileWriter fw = null;
				try {
					// SAVE similarity.txt
					String pathfileString=Utilities.DefaultFilePath() +"/similarity.txt";
					
					if(OSinfo.isWindows()) {pathfileString=Utilities.DefaultFilePath() +"\\similarity.txt";  } // Windows, Linux, MacOS?
					//if(OSinfo.isMacOS()) {pathfileString=Utilities.DefaultFilePath() +"/similarity.txt";    } // Windows, Linux, MacOS?	
					//if(OSinfo.isLinux()) {pathfileString=Utilities.DefaultFilePath() +"/similarity.txt";    } // Windows, Linux, MacOS?	
					 
					lblPathFileOfSimilarityMatrix.setText("Similarity was saved to  "+pathfileString);
					fw = new FileWriter(pathfileString);
					for (int i = 0; i < GlobalVars.SimilarityMatrix.length; i++) {			 
						
						if(OSinfo.isWindows()) {
						fw.write(Double.toString(GlobalVars.SimilarityMatrix[i][0]) +"\t"
								+Double.toString(GlobalVars.SimilarityMatrix[i][1]) +"\t"
								+Double.toString(GlobalVars.SimilarityMatrix[i][2]) +"\r\n");
						}
						else
						{
							
							fw.write(Double.toString(GlobalVars.SimilarityMatrix[i][0]) +"\t"
									+Double.toString(GlobalVars.SimilarityMatrix[i][1]) +"\t"
									+Double.toString(GlobalVars.SimilarityMatrix[i][2]) +"\n");
						}
					}
					fw.close();
					
					// SAVE mergedAngles	
					pathfileString=Utilities.DefaultFilePath() +"/angles.txt";
					
					if(OSinfo.isWindows()) {pathfileString=Utilities.DefaultFilePath() +"\\angles.txt";  } // Windows, Linux, MacOS?
					//if(OSinfo.isMacOS()) {pathfileString=Utilities.DefaultFilePath() +"/similarity.txt";    } // Windows, Linux, MacOS?	
					//if(OSinfo.isLinux()) {pathfileString=Utilities.DefaultFilePath() +"/similarity.txt";    } // Windows, Linux, MacOS?	
					 
					//lblPathFileOfSimilarityMatrix.setText("Similarity was saved to  "+pathfileString);
					fw = new FileWriter(pathfileString);
					for (int i = 0; i < GlobalVars.geneCount ; i++) {
						fw.write(GlobalVars.spotIDs[i] +"\t");
						fw.write(GlobalVars.geneSymbols[i] +"\t");
						
						for (int j = 0; j < GlobalVars.mergedAngles[0].length-1; j++) {
							
							fw.write(GlobalVars.mergedAngles[i][j] +"\t");
							
						}
						if(OSinfo.isWindows()) {
						fw.write(GlobalVars.mergedAngles[i][GlobalVars.mergedAngles[0].length-1] +"\r\n");}
						else
						{
							fw.write(GlobalVars.mergedAngles[i][GlobalVars.mergedAngles[0].length-1] +"\n");
						}
						
					}
					fw.close();
					
					// SAVE AbsoluteChangesAdjacentPoint_median
					
					
					
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		
		
		// calculate and set to GlobalVars.EuclideanMatrix
		btnOk.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// public static double[][] originExpr=null;
				int timePointCount = GlobalVars.pointCount;
				if(GlobalVars.pointCount==0)
				{
					
					MessageBox messageBox =
						    new MessageBox(shell,
						     SWT.OK|
						     SWT.ICON_WARNING);
						messageBox.setMessage("Gene expression was not loaded.");
						messageBox.open(); 		
						return;
					
				}
				
				double[][] ShiftedExpr = GlobalVars.shiftedExpr;
				int geneCount = ShiftedExpr.length;
				
				
				
				// if "Euclidean or Correlation (Only)" checked
				if (btnEuclideanOrCorrelation.getSelection()) {
					
					// EuclideanDistance on originExpr
					if (btnEuclideanDistance.getSelection()) {
						//Simple EuclideanDistance only
						GlobalVars.EuclideanMatrix= new double[geneCount * geneCount-geneCount][3];
						int n = 0;
						for (int i = 0; i < geneCount; i++) {
							for (int j = 0; j < i; j++) {				
								
								 
								GlobalVars.EuclideanMatrix[n][0] = i + 1;
								GlobalVars.EuclideanMatrix[n][1] = j + 1;
								double tmp_sum=0;
								for (int k = 0; k < GlobalVars.pointCount; k++) {
									tmp_sum+= (GlobalVars.originExpr[i][k]-GlobalVars.originExpr[j][k])*
											 (GlobalVars.originExpr[i][k]-GlobalVars.originExpr[j][k]);									 
								}						
								GlobalVars.EuclideanMatrix[n][2] = Math.sqrt(tmp_sum);
								
								
								n++;
								if (i != j) {									
									
									GlobalVars.EuclideanMatrix[n][1] = i + 1;
									GlobalVars.EuclideanMatrix[n][0] = j + 1;
									GlobalVars.EuclideanMatrix[n][2] = GlobalVars.EuclideanMatrix[n - 1][2];
									
									n++;
								}

							}
						}
						//transform EuclideanMatrix to GlobalVars.SimilarityMatrix
						GlobalVars.SimilarityMatrix=new double[n][3];
						for (int i = 0; i < n; i++) {
							GlobalVars.SimilarityMatrix[i][0] = GlobalVars.EuclideanMatrix[i][0];
							GlobalVars.SimilarityMatrix[i][1] = GlobalVars.EuclideanMatrix[i][1];
							GlobalVars.SimilarityMatrix[i][2] =-GlobalVars.EuclideanMatrix[i][2];
						}
						
						
					}
					if (btnPearsonCorrelatedCoefficient.getSelection()) // PearsonsCorrelation on originExpr
					{  
						//Simple Correlation only
						double [][]similarity	= new double[geneCount * geneCount][3];
						PearsonsCorrelation p = new PearsonsCorrelation();
						int n = 0;
						for (int i = 0; i < geneCount; i++) {
							for (int j = 0; j < i; j++) {
								similarity[n][0] = i + 1;
								similarity[n][1] = j + 1;
								similarity[n][2] = p.correlation(
										GlobalVars.originExpr[i], GlobalVars.originExpr[j]);								
								
								n++;
								if (i != j) {
									similarity[n][1] = i + 1;
									similarity[n][0] = j + 1;
									similarity[n][2] = similarity[n - 1][2];									
											
									n++;
								}

							}
						}
						GlobalVars.SimilarityMatrix=new double[n][3];
						for (int i = 0; i < n; i++) {
							GlobalVars.SimilarityMatrix[i][0] = similarity[i][0];
							GlobalVars.SimilarityMatrix[i][1] = similarity[i][1];
							GlobalVars.SimilarityMatrix[i][2] =similarity[i][2];
						}
					}
					
					if (btnDTW.getSelection()) // DTW on originExpr
					{  
						//Simple Correlation only
						double [][]similarity	= new double[geneCount * geneCount][3];
						PearsonsCorrelation p = new PearsonsCorrelation();
						int n = 0;
						
						 Builder ts_builder1,ts_builder2;
						 TimeSeries ts1,ts2;
						 
						for (int i = 0; i < geneCount; i++) {
							for (int j = 0; j < i; j++) {
								similarity[n][0] = i + 1;
								similarity[n][1] = j + 1;
								
								ts_builder1=TimeSeriesBase.builder();
								ts_builder2=TimeSeriesBase.builder();
								for (int kk = 0; kk < timePointCount; kk++) 
								{   ts_builder1.add(kk, GlobalVars.originExpr[i][kk]); 
									ts_builder2.add(kk, GlobalVars.originExpr[j][kk]); 	
								}
								ts1 =ts_builder1.build();
								ts2 =ts_builder2.build();								
								 
								// search radius
								similarity[n][2] = FastDTW.compare(ts1, ts2, 10, Distances.EUCLIDEAN_DISTANCE).getDistance();								
								
								n++;
								if (i != j) {
									similarity[n][1] = i + 1;
									similarity[n][0] = j + 1;
									similarity[n][2] = similarity[n - 1][2];									
											
									n++;
								}

							}
						}
						GlobalVars.SimilarityMatrix=new double[n][3];
						for (int i = 0; i < n; i++) {
							GlobalVars.SimilarityMatrix[i][0] = similarity[i][0];
							GlobalVars.SimilarityMatrix[i][1] = similarity[i][1];
							GlobalVars.SimilarityMatrix[i][2] =similarity[i][2];
						}
					}
				
				}
				
				// Angles: if "Euclidean or Correlation (Only)" not checked
				if ( ! btnEuclideanOrCorrelation.getSelection()) {
					// Our similarity measure , angles + Eucli + Correl
					//GlobalVars.AbsoluteChangesAdjacentPoint= new double[geneCount][timePointCount - 1];
					GlobalVars.LocalAnglesTwoAdjacentPoints = new double[geneCount][timePointCount - 1];
					GlobalVars.GlobalAnglesEveryTimePoint = new double[geneCount][timePointCount - 1];

					for (int i = 0; i < geneCount; i++) {
						for (int j = 1; j < timePointCount; j++) {
							if (btnLocalAnglestwo.getSelection()) { // every two adjacent time points
								
								//GlobalVars.AbsoluteChangesAdjacentPoint[i][j - 1] = Math
								//		.abs(ShiftedExpr[i][j] - ShiftedExpr[i][j - 1]);
								//GlobalVars.LocalAnglesTwoAdjacentPoints[i][j - 1] = Math.atan((ShiftedExpr[i][j] - ShiftedExpr[i][j - 1]) / (GlobalVars.timePoints[j] - GlobalVars.timePoints[j - 1]));
								GlobalVars.LocalAnglesTwoAdjacentPoints[i][j - 1] = Math.atan((ShiftedExpr[i][j] - ShiftedExpr[i][j - 1]) / ( GlobalVars.AbsoluteChangesAdjacentPoint_median ));
								
								
								GlobalVars.GlobalAnglesEveryTimePoint[i][j - 1] = Math.atan(ShiftedExpr[i][j]);

							}
							 

						}
					}
					
					
					// get median of 
					// Create a new list to store the items
				    //double[] numArray = new double[GlobalVars.AbsoluteChangesAdjacentPoint.length*GlobalVars.AbsoluteChangesAdjacentPoint[0].length];
				    // keep track of where we are.
				    //int listPos = 0;
				    // iterate over the entire 2d array adding each integer
				   // for(int i = 0 ; i < GlobalVars.AbsoluteChangesAdjacentPoint.length; i++) {
				   //     for(int j = 0; j < GlobalVars.AbsoluteChangesAdjacentPoint.length; j++) {
				    //    	numArray[listPos++] = GlobalVars.AbsoluteChangesAdjacentPoint[i][j];
				    //    }
				   // }
				    // sort the list.				  
					//Arrays.sort(numArray);
					//double median;
					//if (numArray.length % 2 == 0)
					//    median = ((double)numArray[numArray.length/2] + (double)numArray[numArray.length/2 - 1])/2;
					//else
					//    median = (double) numArray[numArray.length/2];
					
					//GlobalVars.AbsoluteChangesAdjacentPoint_median=median;
					

					// the matrix is symmetrical, a triangle matrix need to be
					// computed.
					double [][]similarity	= new double[geneCount * geneCount][3];
					GlobalVars.EuclideanMatrix= new double[geneCount * geneCount-geneCount][3];

					// merge local angles and global angles
					//double[][] mergedAngles = new double[geneCount][2 * timePointCount - 2];
					GlobalVars.mergedAngles = new double[geneCount][2 * timePointCount - 2];
					for (int i = 0; i < geneCount; i++) {
						for (int j = 0; j < timePointCount - 1; j++) {
							GlobalVars.mergedAngles[i][j] = GlobalVars.LocalAnglesTwoAdjacentPoints[i][j];
							GlobalVars.mergedAngles[i][j + timePointCount - 1] = GlobalVars.GlobalAnglesEveryTimePoint[i][j];
						}
					}

					// correlation & Euclidean distance
					// [Euclidean] P D'haeseleer. How does gene expression clustering work? Nature biotechnology, 2005
					PearsonsCorrelation p = new PearsonsCorrelation();
					int n = 0;
					for (int i = 0; i < geneCount; i++) {
						for (int j = 0; j < i; j++) {
							similarity[n][0] = i + 1;
							similarity[n][1] = j + 1;
							similarity[n][2] = p.correlation(GlobalVars.mergedAngles[i], GlobalVars.mergedAngles[j]); // PearsonsCorrelation
							
							 
							GlobalVars.EuclideanMatrix[n][0] = i + 1;
							GlobalVars.EuclideanMatrix[n][1] = j + 1;
							double tmp_sum=0;
							for (int k = 0; k < GlobalVars.pointCount; k++) {
								tmp_sum+= (GlobalVars.originExpr[i][k]-GlobalVars.originExpr[j][k])*
										 (GlobalVars.originExpr[i][k]-GlobalVars.originExpr[j][k]);									 
							}						
							GlobalVars.EuclideanMatrix[n][2] = Math.sqrt(tmp_sum);
							
							
							n++;
							if (i != j) {
								similarity[n][1] = i + 1;
								similarity[n][0] = j + 1;
								similarity[n][2] = similarity[n - 1][2];
								
								GlobalVars.EuclideanMatrix[n][1] = i + 1;
								GlobalVars.EuclideanMatrix[n][0] = j + 1;
								GlobalVars.EuclideanMatrix[n][2] = GlobalVars.EuclideanMatrix[n - 1][2]; //  EuclideanMatrix
								
								n++;
							}

						}
					}
					GlobalVars.SimilarityMatrix=new double[n][3];
					for (int i = 0; i < n; i++) {
						GlobalVars.SimilarityMatrix[i][0] = similarity[i][0]; 
						GlobalVars.SimilarityMatrix[i][1] = similarity[i][1];
						GlobalVars.SimilarityMatrix[i][2] = similarity[i][2]; // PearsonsCorrelation
					}
					
					
					// SimilarityMatrix.distances
					GlobalVars.distances =  new double[geneCount][geneCount];
					
					for (int i = 0; i < geneCount; i++) {
						for (int j = 0; j < geneCount ; j++) {
							
							double tmp_sum=0;
							for (int k = 0; k <  GlobalVars.mergedAngles[0].length; k++) {
								tmp_sum+= (GlobalVars.mergedAngles[i][k]-GlobalVars.mergedAngles[j][k])*
										 (GlobalVars.mergedAngles[i][k]-GlobalVars.mergedAngles[j][k]);									 
							}					
							
							
							GlobalVars.distances [i][j] = Math.sqrt(tmp_sum);;
							 
						}
					}
					// SAVE SimilarityMatrix.distances
					// 
					FileWriter fw = null;
					try {
						// SAVE similarity.txt
						String pathfileString=Utilities.DefaultFilePath() +"/distances.txt";
						
						if(OSinfo.isWindows()) {pathfileString=Utilities.DefaultFilePath() +"\\distances.txt";  } // Windows, Linux, MacOS?
						//if(OSinfo.isMacOS()) {pathfileString=Utilities.DefaultFilePath() +"/similarity.txt";    } // Windows, Linux, MacOS?	
						//if(OSinfo.isLinux()) {pathfileString=Utilities.DefaultFilePath() +"/similarity.txt";    } // Windows, Linux, MacOS?	
						 
						 
						fw = new FileWriter(pathfileString);
						for (int i = 0; i < geneCount; i++) {
							for (int j = 0; j < geneCount-1 ; j++) {							
								fw.write(GlobalVars.distances [i][j] +"\t");	
							}
							if(OSinfo.isWindows()) {
								fw.write(GlobalVars.distances [i][geneCount-1] +"\r\n");
							}
							else
							{								
								fw.write(GlobalVars.distances [i][geneCount-1] +"\n");
							}
						}						
					 
						fw.close();			
						
						
						
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					
					
				}
				
				
			
				
				/*MessageBox mBox=new MessageBox(shell);
				mBox.setMessage("OK");
				mBox.open();*/
				// MessageBox messageBox =new MessageBox(shell, SWT.OK|SWT.ICON_WARNING);
				// messageBox.setMessage("Similarity Matrix was calculated. Please save Similarity Matrix file.");
				// messageBox.open(); 						
					
				lblMessage.setText("Similarity was calculated.");
				MessageBox messageBox =
					    new MessageBox(shell,
					     SWT.OK|
					     SWT.ICON_WARNING);
					messageBox.setMessage("Similarity was calculated.");
					messageBox.open(); 		
					return;
				

			}
		});
		

	}
}
