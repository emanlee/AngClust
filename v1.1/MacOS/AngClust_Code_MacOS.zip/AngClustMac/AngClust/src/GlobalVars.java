import java.util.Vector;

public class GlobalVars {

	//expression data files
	private static String geneExpressionDataFile = "";

	public static String getGeneExpressionDataFile() {
		return geneExpressionDataFile;
	}

	public static void setGeneExpressionDataFile(String fileFullName) {
		geneExpressionDataFile = fileFullName;
	}

	// processed data, well-formated data
	public static double[] timePoints=null; //0.5,1,2,4,6;  used to draw figures; not   used to calculate angles
	public static int[] rowIDs=null;//integer, unique
	public static String[] spotIDs=null;// digital or chars
	public static String[] geneSymbols=null; // chars
	public static int pointCount=0; // count of time points
	public static double[][] originExpr=null; // double
	public static double[][] shiftedExpr=null; // double, shifted, moved
	public static double[][] localAngles=null; // angles between adjacent points, local trends
	public static double[][] pointAngles=null; // global trends, 
	public static int geneCount=0;
	public static  String lineEnd="\n"; //Unix, Linux
	public static  String pathfileConnector= "/"; //Unix, Linux
	//
	public static Vector geneAssociation=null;
	
	//
	public static double[][] LocalAnglesTwoAdjacentPoints=null; // 
	public static double[][] GlobalAnglesEveryTimePoint=null; // 
	public static double[][] AbsoluteChangesAdjacentPoint=null; // Absolute of expression changes between to adjacent points 
	public static double[][] mergedAngles=null; //
	public static double  AbsoluteChangesAdjacentPoint_median=0; 
	public static double[][] SimilarityMatrix=null; // for AP Clustering
	public static double[][] distances=null; //  from: https://github.com/lbehnke/hierarchical-clustering-java/blob/master/README.md
	public static double[][] EuclideanMatrix=null; // original expression, Eucli distance,for AP Clustering
	public static double[][] CorrelationMatrix=null; // original expression, Correlation,for AP Clustering
	
	public static String clusterFilesPath="";
	
	public static String TimeUnit=""; //used for the X axis of the XYLineChart.
	
	public static int  EuclideanPercentage=-1; // Euclidean+PCC, percentageOfEuclidean
	public static String Species=""; // Human,yeast,mice
 }
