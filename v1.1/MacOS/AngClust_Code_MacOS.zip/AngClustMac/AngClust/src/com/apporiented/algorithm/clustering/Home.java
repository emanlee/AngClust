package com.apporiented.algorithm.clustering;

import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;

import com.apporiented.algorithm.clustering.visualization.DendrogramPanel;

public class Home {

	 static  GraphicsConfiguration gc;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] names = new String[] { "O1", "O2", "O3", "O4", "O5", "O6" };
		double[][] distances = new double[][] { 
		    { 0, 1, 9, 7, 11, 14 },
		    { 1, 0, 4, 3, 8, 10 }, 
		    { 9, 4, 0, 9, 2, 8 },
		    { 7, 3, 9, 0, 6, 13 }, 
		    { 11, 8, 2, 6, 0, 10 },
		    { 14, 10, 8, 13, 10, 0 }};

		ClusteringAlgorithm alg = new DefaultClusteringAlgorithm();
		Cluster cluster = alg.performClustering(distances, names,
		    new AverageLinkageStrategy());
		
		 
		
		DendrogramPanel dp = new DendrogramPanel();
		dp.setModel(cluster);
		
		 
		JFrame frame= new JFrame(gc);	
		frame.setTitle("Welecome to JavaTutorial.net");
		frame.setSize(600, 400);
		frame.add(dp, BorderLayout.CENTER);
		frame.setVisible(true);
		

	}

}
