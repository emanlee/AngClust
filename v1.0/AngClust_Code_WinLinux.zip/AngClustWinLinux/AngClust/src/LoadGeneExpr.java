import java.awt.Font;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;
import java.util.zip.GZIPInputStream;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;

//import javafx.scene.text.FontWeight;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.FileDialog;

import java.util.StringTokenizer;

// Load gene expression data
// todo: click Cancel of FileDialog -- error
// todo: filter, merge, transform

public class LoadGeneExpr {

	protected Shell shell;
	private Text txtFullFileName;
	private boolean isSpotIdsIncluded = false;
	private Text txtTimePoints;
	private Button btnSpotIdsIncluded;
	private Text txtTimeUnit;

	public static void main(String[] args) {
		try {
			LoadGeneExpr window = new LoadGeneExpr();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	protected void createContents() {
		shell = new Shell();
		shell.setSize(494, 317);
		shell.setText("Load Gene Expression Data");
		int width=shell.getDisplay().getBounds().width; // �ҵ�createContents����������õ���Ļ�Ŀ�ȡ�
		int height=shell.getDisplay().getBounds().height; // ����������У��õ���Ļ�ĸ߶ȡ�
		// �õ���Ļ�Ŀ�߶ȼ�ȥshell���ڵĿ�Ⱥ͸߶ȣ�����2�õ����ڵ����Ͻ����ꡣ
		int x=(width-shell.getBounds().width)/2;
		int y=(height-shell.getBounds().height)/2;
		shell.setLocation(x, y);
		
		Button btnBrowseFile = new Button(shell, SWT.NONE);
		Button btnViewData = new Button(shell, SWT.NONE);
		Button btnLoadData = new Button(shell, SWT.NONE);
		Button btnClose = new Button(shell, SWT.NONE);
		Label lblTimePoints = new Label(shell, SWT.NONE);
		Label lblNewLabel = new Label(shell, SWT.NONE);
		Label lblUnit = new Label(shell, SWT.NONE);
		Label lblDataFile = new Label(shell, SWT.NONE);
		btnSpotIdsIncluded = new Button(shell, SWT.CHECK);
		txtFullFileName = new Text(shell, SWT.BORDER);
		txtTimeUnit = new Text(shell, SWT.BORDER);
		txtTimePoints = new Text(shell, SWT.BORDER);
		
		int buttonSizeWidth=98;
		int buttonSizeHeight=24;
		int buttonPositionX=358;
		
		lblNewLabel.setBounds(10, 10, 148, buttonSizeHeight);
		
		final Display display = Display.getDefault(); 
		//final org.eclipse.swt.graphics.Font myfont=new org.eclipse.swt.graphics.Font(display,"Courier",9,SWT.NORMAL);
		 
		//lblNewLabel.setFont(myfont);		
		lblNewLabel.setText("Gene Expression Data");
	 
		 
		
		lblTimePoints.setBounds(10, 30+5, 72, buttonSizeHeight);
		txtTimePoints.setBounds(88+5, 30+5, 190, buttonSizeHeight);
		
		lblUnit.setBounds(10, 30+30+5, 72, buttonSizeHeight);
		txtTimeUnit.setBounds(88+5, 30+30+5, 190, buttonSizeHeight);
		
		btnSpotIdsIncluded.setBounds(10, 30+30+30+5, 275, buttonSizeHeight);
		
		lblDataFile.setBounds(10, 30+30+30+30+5, 89, buttonSizeHeight);
		txtFullFileName.setBounds(10, 30+30+30+30+30+5, 456, buttonSizeHeight);
		
		
		btnBrowseFile.setBounds(buttonPositionX-100, 30+30+30+30+30+30+5, buttonSizeWidth, buttonSizeHeight);
		btnLoadData.setBounds(buttonPositionX, 30+30+30+30+30+30+5 , buttonSizeWidth, buttonSizeHeight);
		
		
		btnViewData.setBounds(buttonPositionX, 30+30+30+30+30+30+30+5, buttonSizeWidth, buttonSizeHeight);
		btnClose.setBounds(buttonPositionX, 30+30+30+30+30+30+30+30+5 , buttonSizeWidth, buttonSizeHeight);
		
		
		
		lblTimePoints.setText("Time Points");
		
		txtTimePoints.setText(""); // demo: 0.5,1,2,4,6 
		
		txtTimePoints.setToolTipText("Time seperated by commas, i.e. 0.5, 1, 2, 4, 6");
		
		
		lblUnit.setText("Unit");
		
		
		txtTimeUnit.setText(""); // demo: Hours 
		
		txtTimeUnit.setToolTipText("Time unit, i.e. Minute, Hour, Day, Month, Year, etc.");
		
		lblDataFile.setText("Data File");	
			
		
		txtFullFileName.setToolTipText("Gene expression file. Each row reprents a gene. \r\n First column: gene ID/spot ID. Second column: gene symbol. Rest columns: gene expression. ");// demo_data.txt

		
		btnBrowseFile.setText("Browse ...");
		btnBrowseFile.setToolTipText("Select a gene expression file.");
		
		btnViewData.setText("View Data");
		btnViewData.setToolTipText("View gene expression in a new window.");
		
		
		btnSpotIdsIncluded.setSelection(true);
		
		btnLoadData.setText("Load Data");
		btnLoadData.setToolTipText("Load gene expression data. ");
		
		btnClose.setText("Close");		
		
		btnSpotIdsIncluded.setText("Spot IDs included in the data file");

		
		
		
		// Browse
		
		btnBrowseFile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// browse file
				FileDialog dialog = new FileDialog(shell.getShell(), SWT.OPEN);
				dialog.setFilterPath("");
				dialog.setText("Browse Gene Expression Data File");
				dialog.setFileName("");
				dialog.setFilterNames(new String[] { "Text File (*.txt)",
						"All files(*.*)" });
				dialog.setFilterExtensions(new String[] { "*.txt", "*.*" });
				String fileName = dialog.open();
				if (fileName!=null &&  !fileName.isEmpty()) {
					txtFullFileName.setText(fileName);

					GlobalVars.setGeneExpressionDataFile(fileName);

					// Load
					// LineNumber,SpotID,GeneSymbol,Value1,Value2,... ( 2-9,9-20
					// time points)
				}
				else
				{
					return;
				}

			}
		});
		

		// View
		
		btnViewData.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				//
				String expressionDataFile = txtFullFileName.getText();				
				
				BufferedReader bReader = null;
				
				if(expressionDataFile.trim().length()==0) // if not select file. exit.
				{
					MessageBox messageBox =
						    new MessageBox(shell,
						     SWT.OK|
						     SWT.ICON_WARNING);
						messageBox.setMessage("Please select gene expression file.");
						messageBox.open(); 		
						return;
				}

				try {

					// tries first reading as a GZIP then a regular
					try {
						bReader = new BufferedReader(new InputStreamReader(
								new GZIPInputStream(new FileInputStream(
										expressionDataFile))));
					} catch (IOException ex) {
						bReader = new BufferedReader(new FileReader(
								expressionDataFile));
					}

					String szLine = bReader.readLine();
					int nColumnsCount;
					Vector vColumnNames;
					StringTokenizer st;
					StringTokenizer st2;
					if (szLine == null) {
						nColumnsCount = 0;
						vColumnNames = new Vector();
					} else {
						// reads in header line
						st = new StringTokenizer(szLine, "\t");
						st2 = new StringTokenizer(szLine, "\t", true);
						nColumnsCount = st2.countTokens() - st.countTokens()
								+ 1;
						vColumnNames = new Vector(nColumnsCount);

						for (int nindex = 0; nindex < nColumnsCount; nindex++) {
							if (!st2.hasMoreTokens()) {
								vColumnNames.add("");
							} else {
								String sztoken = st2.nextToken();
								if (!sztoken.equals("\t")) {
									vColumnNames.add(sztoken);
									if (st2.hasMoreTokens()) {
										st2.nextToken();
									}
								} else {
									vColumnNames.add("");
								}
							}
						}
					}

					// reads in the rest of the data
					Vector vTableData = new Vector();
					while ((szLine = bReader.readLine()) != null) {
						st2 = new StringTokenizer(szLine, "\t", true);
						Vector vrow = new Vector(nColumnsCount);
						for (int nindex = 0; nindex < nColumnsCount; nindex++) {
							if (st2.hasMoreTokens()) {
								String sztoken = st2.nextToken();
								if (!sztoken.equals("\t")) {
									vrow.add(sztoken);
									if (st2.hasMoreTokens())
										st2.nextToken();
								} else {
									vrow.add("");
								}
							} else {
								vrow.add("");
							}
						}
						vTableData.add(vrow);
					}

					// Display , todo
					DataTable window = new DataTable("Gene Expression Data",
							vColumnNames, vTableData);
					window.open();
				} catch (FileNotFoundException ex) {
					final FileNotFoundException fex = ex;

					javax.swing.SwingUtilities.invokeLater(new Runnable() {
						public void run() {

							fex.printStackTrace(System.out);
						}
					});
				} catch (IOException ex) {
					final IOException fex = ex;

					javax.swing.SwingUtilities.invokeLater(new Runnable() {
						public void run() {

							fex.printStackTrace(System.out);
						}
					});
				} finally {
					try {
						if (bReader != null) {
							bReader.close();
						}
					} catch (IOException ex) {
						final IOException fex = ex;

						javax.swing.SwingUtilities.invokeLater(new Runnable() {
							public void run() {

								fex.printStackTrace(System.out);
							}
						});
					}
				}

				//

			}
		});
		

		// Repeat
		//Button btnRepeatData = new Button(shell, SWT.NONE);
		//btnRepeatData.setText("Repeat Data");
		//btnRepeatData.setBounds(150, 145, 98, 22);

		// LogNormailize
		//Button btnLogNormailizeData = new Button(shell, SWT.RADIO);
		//btnLogNormailizeData.setBounds(41, 186, 148, 16);
		//btnLogNormailizeData.setText("Log normailize data");

		// Normalize
		//Button btnNormalizeData = new Button(shell, SWT.RADIO);
		//btnNormalizeData.setSelection(true);
		//btnNormalizeData.setBounds(41, 208, 148, 16);
		//btnNormalizeData.setText("Normalize data");

		// NoNormalization
		//Button btnNoNormalizationadd = new Button(shell, SWT.RADIO);
		//btnNoNormalizationadd.setBounds(41, 230, 164, 16);
		//btnNoNormalizationadd.setText("No normalization/add 0");

		
		
		btnSpotIdsIncluded.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (btnSpotIdsIncluded.getSelection())
					isSpotIdsIncluded = true;
				else
					isSpotIdsIncluded = false;
			}
		});
		
		btnLoadData.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				String expressionDataFile = txtFullFileName.getText();			
				if(expressionDataFile.trim().length()==0) // if not select file. exit.
				{
					MessageBox messageBox =
						    new MessageBox(shell,
						     SWT.OK|
						     SWT.ICON_WARNING);
						messageBox.setMessage("Please select gene expression file.");
						messageBox.open(); 		
						return;
				}
				
				
				// get time points from text box, and save to GlobalVars.timePoints
				// time points , 0.5,1,2,4,6
				String timePointString=txtTimePoints.getText().trim().replaceAll(" +","").replace('，',',').replace('。',',');
				String[]timePointStrings= timePointString.split(",");
				double[]timePointDoubles=new double[timePointStrings.length];
				for (int i = 0; i < timePointStrings.length; i++) {
					timePointDoubles[i]=Double.parseDouble(timePointStrings[i]);
				}
				GlobalVars.timePoints=timePointDoubles;
				
				// get time unit from text box, and save to GlobalVars.TimeUnit
				//TimeUnit
				GlobalVars.TimeUnit=txtTimeUnit.getText().trim();
				
				// load data
				//String expressionDataFile = txtFullFileName.getText();
				BufferedReader bReader = null;
				Vector vColumnNames; // store column names
				Vector vTableData = new Vector(); // store data
				int nColumnsCount = 0;
				try {

					// tries first reading as a GZIP then a regular
					try {
						bReader = new BufferedReader(new InputStreamReader(
								new GZIPInputStream(new FileInputStream(
										expressionDataFile))));
					} catch (IOException ex) {
						bReader = new BufferedReader(new FileReader(
								expressionDataFile));
					}

					String szLine = bReader.readLine();

					StringTokenizer st;
					StringTokenizer st2;
					if (szLine == null) {
						nColumnsCount = 0;
						vColumnNames = new Vector();
					} else {
						// reads in header line
						st = new StringTokenizer(szLine, "\t");
						st2 = new StringTokenizer(szLine, "\t", true);
						nColumnsCount = st2.countTokens() - st.countTokens()
								+ 1;
						vColumnNames = new Vector(nColumnsCount);

						for (int nindex = 0; nindex < nColumnsCount; nindex++) {
							if (!st2.hasMoreTokens()) {
								vColumnNames.add("");
							} else {
								String sztoken = st2.nextToken();
								if (!sztoken.equals("\t")) {
									vColumnNames.add(sztoken);
									if (st2.hasMoreTokens()) {
										st2.nextToken();
									}
								} else {
									vColumnNames.add("");
								}
							}
						}
					}

					// reads in the rest of the data

					while ((szLine = bReader.readLine()) != null) {
						//empty lines/rows
						if (szLine.length()<=4) {
							continue;
						}
						
						st2 = new StringTokenizer(szLine, "\t", true);
						Vector vrow = new Vector(nColumnsCount);
						for (int nindex = 0; nindex < nColumnsCount; nindex++) {
							if (st2.hasMoreTokens()) {
								String sztoken = st2.nextToken();
								if (!sztoken.equals("\t")) {
									vrow.add(sztoken);
									if (st2.hasMoreTokens())
										st2.nextToken();
								} else {
									vrow.add("");
								}
							} else {
								vrow.add("");
							}
						}
						vTableData.add(vrow);
					}

				} catch (FileNotFoundException ex) {
					final FileNotFoundException fex = ex;

					javax.swing.SwingUtilities.invokeLater(new Runnable() {
						public void run() {

							fex.printStackTrace(System.out);
						}
					});
				} catch (IOException ex) {
					final IOException fex = ex;

					javax.swing.SwingUtilities.invokeLater(new Runnable() {
						public void run() {

							fex.printStackTrace(System.out);
						}
					});
				} finally {
					try {
						if (bReader != null) {
							bReader.close();
						}
					} catch (IOException ex) {
						final IOException fex = ex;

						javax.swing.SwingUtilities.invokeLater(new Runnable() {
							public void run() {

								fex.printStackTrace(System.out);
							}
						});
					}
				}
				// filter,merge,transform

				// store
				// public static int[] rowIDs;//integer, unique
				// public static String[] spotIDs;// digital or chars
				// public static String[] geneSymbols; // chars
				// public static int pointCount; // count of time points
				// public static double[][] originExpr; // double
				// public static double[][] shiftedExpr; // double, shifted,
				// moved
				// public static double[][] localAngles; // angles between
				// adjacent points, local trends
				// public static double[][] pointAngles; // global trends,
				int geneCount = vTableData.size();
				boolean isIncludeSpotID = btnSpotIdsIncluded.getSelection(); // isIncludeSpotID
				int exprValueCount = nColumnsCount - 1;
				
				GlobalVars.rowIDs=new int[geneCount];	//	rowIDs
				GlobalVars.spotIDs=new String[geneCount];	// spotIDs
				GlobalVars.geneSymbols=new String[geneCount];	// geneSymbols
				
				if (isIncludeSpotID) {
					exprValueCount = nColumnsCount - 1 - 1;					
				}
				GlobalVars.pointCount=exprValueCount; // pointCount
				GlobalVars.originExpr=new double[geneCount][exprValueCount]; // originExpr
				GlobalVars.shiftedExpr=new double[geneCount][exprValueCount]; // shiftedExpr
				for (int i = 0; i < geneCount; i++) {
					GlobalVars.rowIDs[i] = i + 1;

					Vector v = (Vector) (vTableData.elementAt(i));
					String[] stringArray = new String[v.size()];
					for (int index = 0; index < v.size(); index++) {
						stringArray[index] = (String) v.get(index);
					}
					
					if (isIncludeSpotID) { // isIncludeSpotID
						GlobalVars.spotIDs[i] = stringArray[0];
						GlobalVars.geneSymbols[i] = stringArray[1];
						for (int j = 0; j < exprValueCount; j++) {
							GlobalVars.originExpr[i][j]=Double.parseDouble(stringArray[j+2]); 
							GlobalVars.shiftedExpr[i][j]=GlobalVars.originExpr[i][j]-GlobalVars.originExpr[i][0];
						}
					} else {
						 
						GlobalVars.geneSymbols[i] = stringArray[0];
						for (int j = 0; j < exprValueCount; j++) {
							GlobalVars.originExpr[i][j]=Double.parseDouble(stringArray[j+1]); 
							GlobalVars.shiftedExpr[i][j]=GlobalVars.originExpr[i][j]-GlobalVars.originExpr[i][0];
						}

					}

				}
				//shell.dispose();
				// messages
				MessageBox messageBox =
					    new MessageBox(shell,
					     SWT.OK|
					     SWT.ICON_WARNING);
					messageBox.setMessage("Gene expression was loaded.");
					messageBox.open(); 		
					return;
				
			}
		});
		
		btnClose.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
	
		
		

	}
}
